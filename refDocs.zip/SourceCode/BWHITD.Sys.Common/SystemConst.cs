using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Text;

namespace BWHITD.Sys.Common
{
    public class SystemConst
    {
        /// <summary>
        /// db password
        /// </summary>
        private static string strDBPwd = string.Empty;
        private static string strDBPwd_ITDMenu = string.Empty;

        private static DBConnectParams dbConnParam;
        private static DBConnectParams dbConn_ITDMENU = new DBConnectParams();
        private static bool isAssignDBConn = false;
        private static bool isLogToFile = false;
        private static bool isBCP = true;
        private static string strSysKey = string.Empty;

        /// <summary>
        /// Property ConnectionString is used to get database connection string.
        /// </summary>
        public static string DBConnString
        {
            get
            {
                if (!isAssignDBConn)
                {
                    AssignDBConnByFile();
                }

                return dbConnParam.ToString();
            }
            set
            {
                dbConnParam = new DBConnectParams(value);
                if (dbConnParam.VerifyType == VerifyTypeEnum.Database && string.IsNullOrEmpty(dbConnParam.Password))
                {
                    dbConnParam.Password = DBPwd;
                }

                isAssignDBConn = true;
            }
        }

        public static bool IsAssignDBConn
        {
            get
            {
                if (dbConnParam == null || dbConnParam.IsEmpty)
                    return false;
                return isAssignDBConn;
            }
        }

        public static DBConnectParams DBConnParam
        {
            get
            {
                if (!isAssignDBConn)
                    AssignDBConnByFile();

                return dbConnParam;
            }
            set
            {
                dbConnParam = value;
                isAssignDBConn = true;
            }
        }

        public static DBConnectParams DBConn_ITDMENU
        {
            get
            {
                return dbConn_ITDMENU;
            }
            set
            {
                dbConn_ITDMENU = value;
            }
        }

        public static bool IsLogToFile
        {
            get { return isLogToFile; }
            set { isLogToFile = value; }
        }

        public static string SysKey
        {
            get
            {
                return strSysKey;
            }
        }

        public static bool IsBCP
        {
            get
            {
                return isBCP;
            }
        }

        public static void AssignDBConnByFile()
        {
            string strNormalConn = string.Empty;
            string strITDMenuConn = string.Empty;

            ////CHECK Config.xml File
            string configFileFullName = Path.Combine(SysUtil.GetAssemblyDirectory(), "ConfigFile.xml");
            if (File.Exists(configFileFullName))
            {
                using (XmlHelper configXML = new XmlHelper(configFileFullName))
                {
                    strSysKey = configXML.ParseByXpath("Config/SysKey");
                    strNormalConn = configXML.ParseByXpath("Config/ConnStr");
                    strITDMenuConn = configXML.ParseByXpath("Config/ITDMenuConnStr");
                }
            }
            else
            {
                strSysKey = ConfigurationManager.AppSettings["SysKey"];

                if (string.IsNullOrEmpty(strSysKey))
                    strSysKey = "CPM";

                ConnectionStringSettings connStrITDMenu = ConfigurationManager.ConnectionStrings["ITDMenuConn"];
                if (connStrITDMenu != null)
                    strITDMenuConn = connStrITDMenu.ConnectionString;

                ////CHECK Web.config OR App.config
                ConnectionStringSettings connStrNormal = ConfigurationManager.ConnectionStrings["ConnectionString"];
                if (connStrNormal != null)
                    strNormalConn = connStrNormal.ConnectionString;
            }

            if (string.IsNullOrEmpty(strNormalConn))
                throw new Exception("Fail to get ConnectionString,Please check config file! ");

            dbConnParam = new DBConnectParams(strNormalConn);
            if (dbConnParam.VerifyType == VerifyTypeEnum.Database && string.IsNullOrEmpty(dbConnParam.Password))
            {
                dbConnParam.Password = DBPwd;
            }

            if (!string.IsNullOrEmpty(strITDMenuConn))
            {
                dbConn_ITDMENU = new DBConnectParams(strITDMenuConn);
                if (dbConn_ITDMENU.VerifyType == VerifyTypeEnum.Database && string.IsNullOrEmpty(dbConn_ITDMENU.Password))
                {
                    dbConn_ITDMENU.Password = DBPwd_ITDMenu;
                }
            }

            //Cancel check IP for BCP.
            //isBCP = SysUtil.CheckNameWithIPAddress(dbConnParam.Server, strSvrIP);
            try
            {
                using (DB dbi = new DB(dbConnParam))
                {
                    dbi.NeedLog = false;
                    isBCP = dbi.ExecScalar("SELECT PARAM_VALUE FROM SYS_PARAM WHERE PARAM_KEY = 'C_BCP'", "N").ToString().ToUpper().Equals("Y");
                }
            }
            catch
            {
                isBCP = false;
            }

            isAssignDBConn = true;
        }

        public static string DBPwd
        {
            private get
            {
                if (string.IsNullOrEmpty(strDBPwd))
                    throw new Exception("DB password is not assign! ");
                return strDBPwd;
            }
            set
            {
                strDBPwd = value;
            }
        }

        public static string DBPwd_ITDMenu
        {
            private get
            {
                if (string.IsNullOrEmpty(strDBPwd_ITDMenu))
                    throw new Exception("ITDMenu DB password is not assign! ");

                return strDBPwd_ITDMenu;
            }
            set
            {
                strDBPwd_ITDMenu = value;
            }
        }
    }
}
