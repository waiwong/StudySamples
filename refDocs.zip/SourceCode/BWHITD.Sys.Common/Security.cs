using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualBasic;

namespace BWHITD.Sys.Common
{
    public class Security
    {
        ////public static string Encryption(string strEncrypt)
        ////{
        ////    string result = string.Empty;
        ////    //Use to encrypte the password
        ////    int strLen = 0;//the lenght of the password
        ////    string tmpStr = null;//the temp password    

        ////    int i = 0;
        ////    try
        ////    {
        ////        strLen = strEncrypt.Length;
        ////        for (i = 1; i <= strLen; i++)
        ////        {
        ////            tmpStr = Strings.Mid(strEncrypt, i, 1);
        ////            tmpStr = Strings.Chr(Strings.Asc(tmpStr) + i).ToString();
        ////            result = result + tmpStr;
        ////        }
        ////    }
        ////    catch (Exception ex)
        ////    {
        ////        Log.LogErr(ex);
        ////        throw;
        ////    }

        ////    return result;
        ////}

        public static string Decryption(string strDecrypt)
        {
            string result = null;
            ////Use to decrypte the password.
            int strLen = 0;
            string tmpStr = null;
            int i = 0;

            try
            {
                strLen = strDecrypt.Length;
                for (i = 1; i <= strLen; i++)
                {
                    tmpStr = Strings.Mid(strDecrypt, i, 1);
                    tmpStr = Strings.Chr(Strings.Asc(tmpStr) - i).ToString();
                    result = result + tmpStr;
                }
            }
            catch (Exception ex)
            {
                Log.LogErr(ex);
                throw;
            }

            return result;
        }

        public static string WebDecryption(string strDecrypt)
        {
            string result = string.Empty;
            try
            {
                ////Use to decrypt the password.
                int strLen = 0;
                string tmpStr = null;
                int i = 0;
                int j = 0;

                strLen = strDecrypt.Length;
                for (i = 1; i <= strLen; i += 2)
                {
                    j = j + 1;
                    tmpStr = Strings.Mid(strDecrypt, i, 2);
                    tmpStr = Strings.Chr(Convert.ToInt32(Conversion.Val("&H" + tmpStr)) - j).ToString();
                    result = result + tmpStr;
                }
            }
            catch (Exception ex)
            {
                Log.LogErr(ex);
                result = strDecrypt;
            }

            return result;
        }

        public static string WebEncryption(string strEncrypt)
        {
            string result = string.Empty;
            try
            {
                ////Use to decrypt the password.
                int strLen = 0;
                string strTmp = null;
                int i = 0;
                int j = 0;
                strLen = strEncrypt.Length;
                for (i = 1; i <= strLen; i++)
                {
                    j = j + 1;
                    strTmp = Strings.Mid(strEncrypt, i, 1);
                    strTmp = Conversion.Hex(Strings.Asc(strTmp) + j);
                    result = result + strTmp;
                }
            }
            catch (Exception ex)
            {
                Log.LogErr(ex);
                result = strEncrypt;
            }

            return result;
        }
    }
}
