﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace BWHITD.Sys.Common
{
    public class Log
    {
        public enum LogType : int
        {
            Error = 0,
            Debug,
            Info,
            Header,
            Footer,
            Pure
        }

        private static string strLogFullName = string.Empty;
        public static string LogFileName
        {
            get
            {
                if (string.IsNullOrEmpty(strLogFullName))
                    strLogFullName = Path.Combine(SysUtil.GetAssemblyDirectory(), "logInfo.log");

                if (File.Exists(strLogFullName))
                {
                    FileInfo fiLogFile = new FileInfo(strLogFullName);
                    if (fiLogFile.Length > 1 * 1024 * 1024)
                    {
                        try
                        {
                            File.Delete(strLogFullName);
                        }
                        catch
                        {
                        }
                    }
                }

                return strLogFullName;
            }
            set
            {
                strLogFullName = value;
            }
        }

        public static string LogFileName_ERROR
        {
            get
            {
                string fileExt = Path.GetExtension(LogFileName);
                string errLogFFN = LogFileName.Replace(fileExt, "_Error" + fileExt);
                if (File.Exists(errLogFFN))
                {
                    FileInfo fiLogFile = new FileInfo(errLogFFN);
                    if (fiLogFile.Length > 1 * 1024 * 1024)
                    {
                        try
                        {
                            File.Delete(errLogFFN);
                        }
                        catch
                        {
                        }
                    }
                }

                return errLogFFN;
            }
        }

        private static string lastMsg = string.Empty;

        public static string LastMsg
        {
            get
            {
                return lastMsg;
            }
        }

        public static void LogErrFormat(string strFormat, params object[] args)
        {
            LogErr(string.Format(strFormat, args), null);
        }

        public static void LogErr(string pLog)
        {
            LogErr(pLog, null);
        }

        public static void LogErr(Exception ex)
        {
            LogErr(string.Empty, ex);
        }

        public static void LogErr(string pLog, Exception ex)
        {
            DoLog(LogType.Error, pLog, ex);
        }

        public static void DelLogFile()
        {
            if (File.Exists(LogFileName))
                File.Delete(LogFileName);

            if (File.Exists(LogFileName_ERROR))
                File.Delete(LogFileName_ERROR);
        }

        private static void DoLog(LogType logType, string pLog, Exception ex)
        {
            DoLog(LogFileName, logType, pLog, ex);
            if (logType == LogType.Error)
                DoLog(LogFileName_ERROR, logType, pLog, ex);
        }

        private static void DoLog(string fileFullName, LogType logType, string pLog, Exception ex)
        {
            try
            {
                string logMsg = string.Empty;
                if (logType == LogType.Header)
                {
                    logMsg = "===========Header===========";
                }
                else if (logType == LogType.Footer)
                {
                    logMsg = "===========Footer===========";
                }
                else
                {
                    if (pLog.Equals(Environment.NewLine))
                    {
                        logMsg = string.Empty;
                    }
                    else
                    {
                        lastMsg = string.Empty;
                        if (logType != LogType.Pure)
                        {
                            if (!string.IsNullOrEmpty(pLog))
                            {
                                lastMsg = pLog;
                            }

                            if (ex != null)
                            {
                                lastMsg = string.Format("0{0} {1} {2}", lastMsg, Environment.NewLine, ex.ToString());
                            }

                            if (lastMsg.StartsWith("0") || lastMsg.StartsWith("1"))
                            {
                                logMsg = lastMsg.Substring(1);
                            }
                            else
                            {
                                logMsg = lastMsg;
                            }

                            logMsg = string.Format("[Begin] {2} [{0}]--{1}", logType.ToString(), logMsg, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:ffff"));
                        }
                        else
                        {
                            logMsg = pLog;
                        }
                    }
                }

                using (FileStream fs = new FileStream(fileFullName, FileMode.Append, FileAccess.Write))
                {
                    using (StreamWriter sw = new StreamWriter(fs, Encoding.UTF8))
                    {
                        sw.WriteLine(logMsg);
                        sw.Flush();
                    }
                }
            }
            catch
            {
            }
        }

        public static void LogInfo(string strMsg)
        {
            DoLog(LogType.Info, strMsg, null);
        }

        public static void LogInfoFormat(string strFormat, params object[] args)
        {
            LogInfo(string.Format(strFormat, args));
        }

        [Conditional("DEBUG"), Conditional("UAT")]
        public static void LogDebug(string message)
        {
            DoLog(LogType.Debug, message, null);
        }

        public static void LogHeader()
        {
            DoLog(LogType.Header, string.Empty, null);
        }

        public static void LogFooter()
        {
            DoLog(LogType.Footer, string.Empty, null);
        }

        public static void LogPure(string message)
        {
            DoLog(LogType.Pure, message, null);
        }

        public static void LogPure(string strFileName, string message)
        {
            DoLog(strFileName, LogType.Pure, message, null);
        }
    }
}
