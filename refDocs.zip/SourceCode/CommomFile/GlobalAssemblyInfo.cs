﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyDescription("Credit Card Assistant System")]
[assembly: AssemblyProduct("Credit Card Assistant System")]
#if DEBUG
[assembly: AssemblyCopyright("CCAS System Debug")]
#elif UAT
[assembly: AssemblyCopyright("CCAS System UAT")]
#else
[assembly: AssemblyCopyright("CCAS System Release")]
#endif

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
#if DEBUG
[assembly: AssemblyVersion("0.2015.1103.*")]
#else
[assembly: AssemblyVersion("0.2015.11.03")]
#endif