﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using BWHITD.Sys.Common;
using BWHITD.Web.Base;

namespace WebProj
{
    public partial class Default : BasePage
    {
        protected void Page_Init(object sender, EventArgs e)
        {
            this.Header.Title = WebProj.Modules.Code.SC.SystemName;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(ContextConst.User))
                ContextConst.User = Page.User.Identity.Name;
                        
//            string srcUrl = string.Empty;
//            #region Get Function Right
//            if (ContextConst.DicFuncRight.Count == 0)
//            {
//                ////Get Function Right
//                using (DB dbi = new DB(SystemConst.DBConnString))
//                {
//                    string sql = string.Format(@"SELECT a.Name_Detail, a.Related_Menu, ISNULL(d.IsRight, 0) AS IsRight
//FROM dbo.BWH_ITD_PERMISSION_NAME a
//LEFT JOIN (
//	SELECT b.Name_ID, b.IsRight
//	FROM dbo.BWH_ITD_PERMISSION_RIGHT b
//	INNER JOIN dbo.BWH_ITD_PERMISSION_GROUP c ON c.IsEnable = 1 AND c.User_GroupID = b.
//		User_GroupID AND c.User_Group IN ('{0}')
//	) d ON d.Name_ID = a.Name_ID
//WHERE a.IsEnable = 1 AND ISNULL(Related_Menu, '') <> '' ORDER BY a.ParentID, a.SortID",
//                         ContextConst.Group.Replace(",", "','"));
//                    System.Data.DataTable dtFunction = dbi.GetDataTable(sql);
//                    Dictionary<string, bool> dicFunctionRight = new Dictionary<string, bool>();
//                    foreach (System.Data.DataRow dr in dtFunction.Rows)
//                    {
//                        string menuPage = dr["Related_Menu"].ToString();
//                        if (!string.IsNullOrEmpty(menuPage))
//                        {
//                            if (!menuPage.StartsWith("/"))
//                                menuPage = "/" + menuPage;

//                            bool pageShow = Convert.ToBoolean(dr["IsRight"]);
//                            if (pageShow && string.IsNullOrEmpty(srcUrl))
//                                srcUrl = menuPage;
//                            if (!dicFunctionRight.ContainsKey(menuPage))
//                                dicFunctionRight.Add(menuPage, pageShow);
//                        }
//                    }

//                    ContextConst.DicFuncRight = dicFunctionRight;
//                }
//            }

//            #endregion

//            string tmpUrl = this.GetRequestQuery("URL");
//            if (!string.IsNullOrEmpty(tmpUrl))
//            {
//                srcUrl = this.ParseURL(tmpUrl, false);
//            }

//            if (ContextConst.DicFuncRight.ContainsKey(srcUrl))
//            {
//                srcUrl = this.ResolveUrl(this.ParseURL(srcUrl, true));
//            }
//            else
//            {
//                string curPage = this.ParseURL(this.mainFrame.Attributes["src"], false);
//                if (!ContextConst.DicFuncRight.ContainsKey(curPage)
//                    || (ContextConst.DicFuncRight.ContainsKey(curPage) && !ContextConst.DicFuncRight[curPage]))
//                {
//                    srcUrl = this.ResolveUrl("~/Modules/Common/Black.aspx");
//                }
//            }

//            Response.Redirect(this.ResolveUrl(!string.IsNullOrEmpty(srcUrl) ? srcUrl : this.ResolveUrl("~/Modules/Common/Black.aspx")));
        }

        private string ParseURL(string strUrl, bool withTilde)
        {
            if (!string.IsNullOrEmpty(strUrl))
            {
                if (!strUrl.StartsWith("/"))
                    strUrl = "/" + strUrl;

                if (withTilde && !strUrl.StartsWith("~"))
                    strUrl = "~" + strUrl;
            }
            return strUrl;
        }
    }
}
