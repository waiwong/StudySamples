﻿using System;
using System.Web;
using System.Web.SessionState;
using BWHITD.Sys.Common;
using BWHITD.Web.Base;

namespace WebProj.Modules.Ajax
{
    /// <summary>
    /// Summary description for $codebehindclassname$
    /// </summary>
    public class KeepSessionAlive : IHttpHandler, IRequiresSessionState
    {
        public void ProcessRequest(HttpContext context)
        {
#if DEBUG || UAT
            System.Text.StringBuilder sblogMsg = new System.Text.StringBuilder();
            sblogMsg.Append("KeepSessionAlive called:");
            if (context.Session != null)
            {
                sblogMsg.AppendFormat("User:{0};Group:{1};Dept:{2}", ContextConst.User, ContextConst.Group, ContextConst.Dept);
            }

            sblogMsg.AppendFormat(";UserIP:{0}", context.Request.UserHostAddress);
            Log.LogInfo(sblogMsg.ToString());
#endif           
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}