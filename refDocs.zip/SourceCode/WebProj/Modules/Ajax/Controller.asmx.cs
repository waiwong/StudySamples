﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.Services;
using BWHITD.Sys.Common;
using BWHITD.Web.Base;
using Newtonsoft.Json;
using WebProj.Modules.Code;

namespace WebProj.Modules.Ajax
{
    /// <summary>
    /// Summary description for Controller
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Controller : System.Web.Services.WebService
    {
        #region CATEGORY
        [WebMethod(EnableSession = true)]
        public void CATEGORY_Get()
        {
            List<SqlParameter> listParam = new List<SqlParameter>();
            string jsonStr = string.Empty;
            HttpRequest req = Context.Request;
            string strC_ID = req.Form["C_ID"];
            string searchName = req.Form["searchName"];
            string searchVal = req.Form["searchVal"];
            string sort = req.Form["sort"];
            string order = req.Form["order"];
            string sqlWhere = string.Empty;
            if (!string.IsNullOrEmpty(searchVal))
            {
                sqlWhere += string.Format(" AND {0} = @{0}", searchName);
                listParam.Add(new SqlParameter("@" + searchName, searchVal));
            }

            if (!string.IsNullOrEmpty(strC_ID))
            {
                sqlWhere += " AND C_ID = @C_ID";
                listParam.Add(new SqlParameter("@C_ID", strC_ID));
            }

            Hashtable ht = new Hashtable();
            DB dbi = new DB(SystemConst.DBConnString);
            string sqlBase = @"SELECT *, CONVERT(NVARCHAR(10), C_ID) +' -' + C_NAME AS C_ID_NAME FROM dbo.CATEGORY WHERE C_DEL=0";
            try
            {
                string sql = sqlBase + sqlWhere;

                if (!string.IsNullOrEmpty(sort))
                    sql += string.Format(" ORDER BY {0} {1}", sort, order);
                ht.Add("rows", dbi.GetDataTable(sql, listParam.ToArray()));
            }
            catch (Exception ex)
            {
                ht.Add("err", ex.Message);
                if (!ht.ContainsKey("rows"))
                {
                    ht.Add("rows", dbi.GetDataTable(sqlBase + " AND 1=2"));
                }
            }

            jsonStr = JsonConvert.SerializeObject(ht);
            ResponseWrite(jsonStr);
        }

        [WebMethod(EnableSession = true)]
        public void CATEGORY_Update()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                HttpRequest req = Context.Request;
                CATEGORY entNew = EntityUtilWeb.Create<CATEGORY>(req);

                string sqlInsert = @"INSERT INTO dbo.CATEGORY (C_NAME) 
                                                        OUTPUT Inserted.C_ID
                                                        VALUES (@C_NAME);";

                string sqlUpdate = @"UPDATE dbo.CATEGORY
                                    SET C_NAME = @C_NAME
                                    WHERE C_ID = @C_ID";

                List<int> listRC = new List<int>();
                List<SqlParameter> listParam = new List<SqlParameter>();
                listParam.Add(new SqlParameter("@C_NAME", entNew.C_NAME));

                dbi.BeginTransaction();

                if (entNew.C_ID <= 0)
                {
                    entNew.C_ID = Convert.ToInt32(dbi.ExecScalar(sqlInsert, listParam.ToArray(), -1));
                    if (entNew.C_ID <= 0)
                    {
                        strResult = "Can not add new item.";
                    }
                }
                else
                {
                    listParam.Add(new SqlParameter("@C_ID", entNew.C_ID));
                    listRC.Add(dbi.ExecNonQuery(sqlUpdate, listParam.ToArray()));
                }

                if (string.IsNullOrEmpty(strResult))
                {
                    bool checkRC = !listRC.Exists((e) => { return e == 0; });
                    if (checkRC)
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Update failed, please try again.";
                    }
                }
                else
                {
                    dbi.AbortTransaction();
                }
            }
            catch (Exception ex)
            {
                if (dbi.IsInTransaction)
                    dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        [WebMethod(EnableSession = true)]
        public void CATEGORY_Delete()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                List<int> listRC = new List<int>();
                string logIDs = Context.Request.Form["C_ID"];

                foreach (string logID in logIDs.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    dbi.BeginTransaction();

                    string sql = @"UPDATE dbo.CATEGORY SET C_DEL=1 WHERE C_ID = @C_ID ";
                    listRC.Add(dbi.ExecNonQuery(sql, CommFunc.InitSqlParam("@C_ID", logID)));

                    if (!listRC.Exists((e) => { return e == 0; }))
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Delete failed, please try again.";
                    }
                }
            }
            catch (Exception ex)
            {
                dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        #endregion

        #region SUPPLIER
        [WebMethod(EnableSession = true)]
        public void SUPPLIER_Get()
        {
            List<SqlParameter> listParam = new List<SqlParameter>();
            string jsonStr = string.Empty;
            HttpRequest req = Context.Request;
            string strC_ID = req.Form["C_ID"];
            string searchName = req.Form["searchName"];
            string searchVal = req.Form["searchVal"];
            string sort = req.Form["sort"];
            string page = req.Form["page"] ?? "1";
            string rowsCnt = req.Form["rows"] ?? "100";
            string order = req.Form["order"];
            string sqlWhere = string.Empty;
            if (!string.IsNullOrEmpty(searchVal))
            {
                sqlWhere += string.Format(" AND {0} LIKE '%' + @{0} + '%'", searchName);
                listParam.Add(new SqlParameter("@" + searchName, searchVal));
            }

            if (!string.IsNullOrEmpty(strC_ID))
            {
                sqlWhere += " AND C_ID = @C_ID";
                listParam.Add(new SqlParameter("@C_ID", strC_ID));
            }

            Hashtable ht = new Hashtable();
            DB dbi = new DB(SystemConst.DBConnString);
            string sqlBase = @"SELECT *, CONVERT(NVARCHAR(10), C_ID) +' - ' + C_SHORTNAME AS C_ID_NAME FROM dbo.SUPPLIER WHERE C_DEL=0";
            string sqlCnt = @"SELECT COUNT(1) FROM dbo.SUPPLIER WHERE C_DEL=0";
            try
            {
                string sql = sqlBase + sqlWhere;
                sqlCnt += sqlWhere;

                if (!string.IsNullOrEmpty(sort))
                    sql += string.Format(" ORDER BY {0} {1}", sort, order);

                int total = Convert.ToInt16(dbi.ExecScalar(sqlCnt, listParam.ToArray(), "0"));
                DataTable dt = dbi.GetPageData(sql, int.Parse(page), int.Parse(rowsCnt), listParam.ToArray());
                ht.Add("rows", dt);
                ht.Add("total", total);
            }
            catch (Exception ex)
            {
                ht.Add("err", ex.Message);
                if (!ht.ContainsKey("rows"))
                {
                    ht.Add("rows", dbi.GetDataTable(sqlBase + " AND 1=2"));
                    ht.Add("total", 0);
                }
            }

            jsonStr = JsonConvert.SerializeObject(ht);
            ResponseWrite(jsonStr);
        }

        [WebMethod(EnableSession = true)]
        public void SUPPLIER_Update()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                HttpRequest req = Context.Request;
                SUPPLIER entNew = EntityUtilWeb.Create<SUPPLIER>(req);

                string sqlInsert = @"INSERT INTO dbo.SUPPLIER (C_NAME, C_SHORTNAME, C_CONTACT_PERSON, C_PHONE, C_FAX, C_EMAIL, C_ADDRESS)
                                     OUTPUT Inserted.C_ID
                                     VALUES (@C_NAME, @C_SHORTNAME, @C_CONTACT_PERSON, @C_PHONE, @C_FAX, @C_EMAIL, @C_ADDRESS);";

                string sqlUpdate = @"UPDATE dbo.SUPPLIER
                                    SET C_NAME = @C_NAME, C_SHORTNAME = @C_SHORTNAME, C_CONTACT_PERSON = @C_CONTACT_PERSON
	                                    , C_PHONE = @C_PHONE, C_FAX = @C_FAX, C_EMAIL = @C_EMAIL, C_ADDRESS = @C_ADDRESS
                                    WHERE C_ID = @C_ID";

                List<int> listRC = new List<int>();
                List<SqlParameter> listParam = EntityUtil.GenerateParams<SUPPLIER>(entNew);
                dbi.BeginTransaction();

                if (entNew.C_ID <= 0)
                {
                    entNew.C_ID = Convert.ToInt32(dbi.ExecScalar(sqlInsert, listParam.ToArray(), -1));
                    if (entNew.C_ID <= 0)
                    {
                        strResult = "Can not add new item.";
                    }
                }
                else
                {
                    listRC.Add(dbi.ExecNonQuery(sqlUpdate, listParam.ToArray()));
                }

                if (string.IsNullOrEmpty(strResult))
                {
                    bool checkRC = !listRC.Exists((e) => { return e == 0; });
                    if (checkRC)
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Update failed, please try again.";
                    }
                }
                else
                {
                    dbi.AbortTransaction();
                }
            }
            catch (Exception ex)
            {
                if (dbi.IsInTransaction)
                    dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        [WebMethod(EnableSession = true)]
        public void SUPPLIER_Delete()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                List<int> listRC = new List<int>();
                string logIDs = Context.Request.Form["C_ID"];

                foreach (string logID in logIDs.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    dbi.BeginTransaction();

                    string sql = @"UPDATE dbo.SUPPLIER SET C_DEL=1 WHERE C_ID = @C_ID ";
                    listRC.Add(dbi.ExecNonQuery(sql, CommFunc.InitSqlParam("@C_ID", logID)));

                    if (!listRC.Exists((e) => { return e == 0; }))
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Delete failed, please try again.";
                    }
                }
            }
            catch (Exception ex)
            {
                dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        #endregion

        #region AC_NAME
        [WebMethod(EnableSession = true)]
        public void AC_NAME_Get()
        {
            List<SqlParameter> listParam = new List<SqlParameter>();
            string jsonStr = string.Empty;
            HttpRequest req = Context.Request;
            string strC_ID = req.Form["C_ID"];
            string searchName = req.Form["searchName"];
            string searchVal = req.Form["searchVal"];
            string sort = req.Form["sort"];
            string order = req.Form["order"];
            string sqlWhere = string.Empty;
            if (!string.IsNullOrEmpty(searchVal))
            {
                sqlWhere += string.Format(" AND {0} LIKE '%' + @{0} + '%'", searchName);
                listParam.Add(new SqlParameter("@" + searchName, searchVal));
            }

            if (!string.IsNullOrEmpty(strC_ID))
            {
                sqlWhere += " AND C_ID = @C_ID";
                listParam.Add(new SqlParameter("@C_ID", strC_ID));
            }

            Hashtable ht = new Hashtable();
            DB dbi = new DB(SystemConst.DBConnString);
            string sqlBase = @"SELECT *,CONVERT(NVARCHAR(10), C_ID) +' -' + C_NAME AS C_ID_NAME FROM dbo.AC_NAME WHERE C_DEL=0";
            try
            {
                string sql = sqlBase + sqlWhere;

                if (!string.IsNullOrEmpty(sort))
                    sql += string.Format(" ORDER BY {0} {1}", sort, order);
                ht.Add("rows", dbi.GetDataTable(sql, listParam.ToArray()));
            }
            catch (Exception ex)
            {
                ht.Add("err", ex.Message);
                if (!ht.ContainsKey("rows"))
                {
                    ht.Add("rows", dbi.GetDataTable(sqlBase + " AND 1=2"));
                }
            }

            jsonStr = JsonConvert.SerializeObject(ht);
            ResponseWrite(jsonStr);
        }

        [WebMethod(EnableSession = true)]
        public void AC_NAME_Update()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                HttpRequest req = Context.Request;
                AC_NAME entNew = EntityUtilWeb.Create<AC_NAME>(req);

                string sqlInsert = @"INSERT INTO dbo.AC_NAME (C_NAME, C_SHORTNAME) 
                                                        OUTPUT Inserted.C_ID
                                                        VALUES (@C_NAME, @C_SHORTNAME);";

                string sqlUpdate = @"UPDATE dbo.AC_NAME
                                    SET C_NAME = @C_NAME,C_SHORTNAME=@C_SHORTNAME
                                    WHERE C_ID = @C_ID";

                List<int> listRC = new List<int>();
                List<SqlParameter> listParam = new List<SqlParameter>();
                listParam.Add(new SqlParameter("@C_NAME", entNew.C_NAME));
                listParam.Add(new SqlParameter("@C_SHORTNAME", entNew.C_SHORTNAME));

                dbi.BeginTransaction();

                if (entNew.C_ID <= 0)
                {
                    entNew.C_ID = Convert.ToInt32(dbi.ExecScalar(sqlInsert, listParam.ToArray(), -1));
                    if (entNew.C_ID <= 0)
                    {
                        strResult = "Can not add new item.";
                    }
                }
                else
                {
                    listParam.Add(new SqlParameter("@C_ID", entNew.C_ID));
                    listRC.Add(dbi.ExecNonQuery(sqlUpdate, listParam.ToArray()));
                }

                if (string.IsNullOrEmpty(strResult))
                {
                    bool checkRC = !listRC.Exists((e) => { return e == 0; });
                    if (checkRC)
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Update failed, please try again.";
                    }
                }
                else
                {
                    dbi.AbortTransaction();
                }
            }
            catch (Exception ex)
            {
                if (dbi.IsInTransaction)
                    dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        [WebMethod(EnableSession = true)]
        public void AC_NAME_Delete()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                List<int> listRC = new List<int>();
                string logIDs = Context.Request.Form["C_ID"];

                foreach (string logID in logIDs.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    dbi.BeginTransaction();

                    string sql = @"UPDATE dbo.AC_NAME SET C_DEL=1 WHERE C_ID = @C_ID ";
                    listRC.Add(dbi.ExecNonQuery(sql, CommFunc.InitSqlParam("@C_ID", logID)));

                    if (!listRC.Exists((e) => { return e == 0; }))
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Delete failed, please try again.";
                    }
                }
            }
            catch (Exception ex)
            {
                dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        #endregion

        #region CCY
        [WebMethod(EnableSession = true)]
        public void CCY_Get()
        {
            List<SqlParameter> listParam = new List<SqlParameter>();
            string jsonStr = string.Empty;
            HttpRequest req = Context.Request;
            string strC_ID = req.Form["C_ID"];
            string searchName = req.Form["searchName"];
            string searchVal = req.Form["searchVal"];
            string sort = req.Form["sort"];
            string order = req.Form["order"];
            string sqlWhere = string.Empty;
            if (!string.IsNullOrEmpty(searchVal))
            {
                sqlWhere += string.Format(" AND {0} = @{0}", searchName);
                listParam.Add(new SqlParameter("@" + searchName, searchVal));
            }

            if (!string.IsNullOrEmpty(strC_ID))
            {
                sqlWhere += " AND C_ID = @C_ID";
                listParam.Add(new SqlParameter("@C_ID", strC_ID));
            }

            Hashtable ht = new Hashtable();
            DB dbi = new DB(SystemConst.DBConnString);
            string sqlBase = @"SELECT *, CONVERT(NVARCHAR(10), C_ID) +' -' + C_NAME AS C_ID_NAME FROM dbo.CCY WHERE C_DEL=0";
            try
            {
                string sql = sqlBase + sqlWhere;

                if (!string.IsNullOrEmpty(sort))
                    sql += string.Format(" ORDER BY {0} {1}", sort, order);
                ht.Add("rows", dbi.GetDataTable(sql, listParam.ToArray()));
            }
            catch (Exception ex)
            {
                ht.Add("err", ex.Message);
                if (!ht.ContainsKey("rows"))
                {
                    ht.Add("rows", dbi.GetDataTable(sqlBase + " AND 1=2"));
                }
            }

            jsonStr = JsonConvert.SerializeObject(ht);
            ResponseWrite(jsonStr);
        }

        [WebMethod(EnableSession = true)]
        public void CCY_Update()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                HttpRequest req = Context.Request;
                CCY entNew = EntityUtilWeb.Create<CCY>(req);

                string sqlInsert = @"INSERT INTO dbo.CCY (C_NAME) 
                                                        OUTPUT Inserted.C_ID
                                                        VALUES (@C_NAME);";

                string sqlUpdate = @"UPDATE dbo.CCY
                                    SET C_NAME = @C_NAME
                                    WHERE C_ID = @C_ID";

                List<int> listRC = new List<int>();
                List<SqlParameter> listParam = new List<SqlParameter>();
                listParam.Add(new SqlParameter("@C_NAME", entNew.C_NAME));

                dbi.BeginTransaction();

                if (entNew.C_ID <= 0)
                {
                    entNew.C_ID = Convert.ToInt32(dbi.ExecScalar(sqlInsert, listParam.ToArray(), -1));
                    if (entNew.C_ID <= 0)
                    {
                        strResult = "Can not add new item.";
                    }
                }
                else
                {
                    listParam.Add(new SqlParameter("@C_ID", entNew.C_ID));
                    listRC.Add(dbi.ExecNonQuery(sqlUpdate, listParam.ToArray()));
                }

                if (string.IsNullOrEmpty(strResult))
                {
                    bool checkRC = !listRC.Exists((e) => { return e == 0; });
                    if (checkRC)
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Update failed, please try again.";
                    }
                }
                else
                {
                    dbi.AbortTransaction();
                }
            }
            catch (Exception ex)
            {
                if (dbi.IsInTransaction)
                    dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        [WebMethod(EnableSession = true)]
        public void CCY_Delete()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                List<int> listRC = new List<int>();
                string logIDs = Context.Request.Form["C_ID"];

                foreach (string logID in logIDs.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    dbi.BeginTransaction();

                    string sql = @"UPDATE dbo.CCY SET C_DEL=1 WHERE C_ID = @C_ID ";
                    listRC.Add(dbi.ExecNonQuery(sql, CommFunc.InitSqlParam("@C_ID", logID)));

                    if (!listRC.Exists((e) => { return e == 0; }))
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Delete failed, please try again.";
                    }
                }
            }
            catch (Exception ex)
            {
                dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        #endregion

        #region CARD_NO
        [WebMethod(EnableSession = true)]
        public void CARD_NO_Get()
        {
            List<SqlParameter> listParam = new List<SqlParameter>();
            string jsonStr = string.Empty;
            HttpRequest req = Context.Request;
            string strC_ID = req.Form["C_ID"];
            string searchName = req.Form["searchName"];
            string searchVal = req.Form["searchVal"];
            string sort = req.Form["sort"];
            string page = req.Form["page"] ?? "1";
            string rowsCnt = req.Form["rows"] ?? "100";
            string order = req.Form["order"];
            string sqlWhere = string.Empty;
            if (!string.IsNullOrEmpty(searchVal))
            {
                sqlWhere += string.Format(" AND {0} LIKE '%' + @{0} + '%'", searchName);
                listParam.Add(new SqlParameter("@" + searchName, searchVal));
            }

            if (!string.IsNullOrEmpty(strC_ID))
            {
                sqlWhere += " AND C_ID = @C_ID";
                listParam.Add(new SqlParameter("@C_ID", strC_ID));
            }

            Hashtable ht = new Hashtable();
            DB dbi = new DB(SystemConst.DBConnString);
            string sqlBase = @"SELECT *, CONVERT(NVARCHAR(10), C_ID) + ' -' + CONVERT(NVARCHAR(10), C_CATNO) + ' -' + C_SERIALNO + ' -' + C_EQUIPMENT AS C_ID_NAME FROM dbo.V_CARD_NO WHERE C_DEL = 0";
            string sqlCnt = @"SELECT COUNT(1) FROM dbo.CARD_NO WHERE C_DEL=0";
            try
            {
                string sql = sqlBase + sqlWhere;
                sqlCnt += sqlWhere;

                if (!string.IsNullOrEmpty(sort))
                    sql += string.Format(" ORDER BY {0} {1}", sort, order);

                int total = Convert.ToInt16(dbi.ExecScalar(sqlCnt, listParam.ToArray(), "0"));
                DataTable dt = dbi.GetPageData(sql, int.Parse(page), int.Parse(rowsCnt), listParam.ToArray());
                ht.Add("rows", dt);
                ht.Add("total", total);
            }
            catch (Exception ex)
            {
                ht.Add("err", ex.Message);
                if (!ht.ContainsKey("rows"))
                {
                    ht.Add("rows", dbi.GetDataTable(sqlBase + " AND 1=2"));
                    ht.Add("total", 0);
                }
            }

            jsonStr = JsonConvert.SerializeObject(ht);
            ResponseWrite(jsonStr);
        }

        [WebMethod(EnableSession = true)]
        public void CARD_NO_EQUIPMENT_Get()
        {
            string jsonStr = string.Empty;
            HttpRequest req = Context.Request;
            Hashtable ht = new Hashtable();
            DB dbi = new DB(SystemConst.DBConnString);
            string sqlBase = @"SELECT DISTINCT C_EQUIPMENT FROM dbo.CARD_NO WHERE C_DEL=0 ";
            try
            {
                DataTable dt = dbi.GetDataTable(sqlBase + " ORDER BY C_EQUIPMENT");
                ht.Add("rows", dt);
            }
            catch (Exception ex)
            {
                ht.Add("err", ex.Message);
                if (!ht.ContainsKey("rows"))
                {
                    ht.Add("rows", dbi.GetDataTable(sqlBase + " AND 1=2"));
                }
            }

            jsonStr = JsonConvert.SerializeObject(ht);
            ResponseWrite(jsonStr);
        }

        [WebMethod(EnableSession = true)]
        public void CARD_NO_VENDOR_Get()
        {
            string jsonStr = string.Empty;
            HttpRequest req = Context.Request;
            Hashtable ht = new Hashtable();
            DB dbi = new DB(SystemConst.DBConnString);
            string sqlBase = @"SELECT DISTINCT C_VENDOR FROM dbo.CARD_NO WHERE C_DEL=0 ";
            try
            {
                DataTable dt = dbi.GetDataTable(sqlBase + " ORDER BY C_VENDOR");
                ht.Add("rows", dt);
            }
            catch (Exception ex)
            {
                ht.Add("err", ex.Message);
                if (!ht.ContainsKey("rows"))
                {
                    ht.Add("rows", dbi.GetDataTable(sqlBase + " AND 1=2"));
                }
            }

            jsonStr = JsonConvert.SerializeObject(ht);
            ResponseWrite(jsonStr);
        }

        [WebMethod(EnableSession = true)]
        public void CARD_NO_Update()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                HttpRequest req = Context.Request;
                CARD_NO entNew = EntityUtilWeb.Create<CARD_NO>(req);
                string sqlInsert = @"INSERT INTO dbo.CARD_NO (
	C_CATNO, C_SERIALNO, C_EQUIPMENT, C_ITD_REF, C_DEPARTMENT, C_VENDOR, C_DN_NO, C_WARRANTY, C_START_DATE
	, C_END_DATE, C_TYPE, C_EQUIPMENT_COST, C_DELIVERY_DATE, C_BUY_MAINTENANCE)
OUTPUT Inserted.C_ID
VALUES (@C_CATNO, @C_SERIALNO, @C_EQUIPMENT, @C_ITD_REF, @C_DEPARTMENT, @C_VENDOR, @C_DN_NO, @C_WARRANTY
	, @C_START_DATE, @C_END_DATE, @C_TYPE, @C_EQUIPMENT_COST, @C_DELIVERY_DATE, @C_BUY_MAINTENANCE)";

                string sqlUpdate = @"UPDATE dbo.CARD_NO
SET C_CATNO = @C_CATNO, C_SERIALNO = @C_SERIALNO, C_EQUIPMENT = @C_EQUIPMENT, C_ITD_REF = @C_ITD_REF
	, C_DEPARTMENT = @C_DEPARTMENT, C_VENDOR = @C_VENDOR, C_DN_NO = @C_DN_NO, C_WARRANTY = @C_WARRANTY
	, C_START_DATE = @C_START_DATE, C_END_DATE = @C_END_DATE, C_TYPE = @C_TYPE
	, C_EQUIPMENT_COST = @C_EQUIPMENT_COST, C_DELIVERY_DATE = @C_DELIVERY_DATE, C_BUY_MAINTENANCE = @C_BUY_MAINTENANCE
WHERE C_ID = @C_ID";

                List<int> listRC = new List<int>();
                List<SqlParameter> listParam = EntityUtil.GenerateParams<CARD_NO>(entNew);
                bool exist = entNew.C_ID > 0;

                dbi.BeginTransaction();

                if (entNew.C_ID <= 0)
                {
                    entNew.C_ID = Convert.ToInt32(dbi.ExecScalar(sqlInsert, listParam.ToArray(), -1));
                    if (entNew.C_ID <= 0)
                    {
                        strResult = "Can not add new item.";
                    }
                }
                else
                {
                    listRC.Add(dbi.ExecNonQuery(sqlUpdate, listParam.ToArray()));
                }

                if (string.IsNullOrEmpty(strResult))
                {
                    bool checkRC = !listRC.Exists((e) => { return e == 0; });
                    if (checkRC)
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = string.Format("{0} failed, please try again.", exist ? "Update" : "Add");
                    }
                }
                else
                {
                    dbi.AbortTransaction();
                }
            }
            catch (Exception ex)
            {
                if (dbi.IsInTransaction)
                    dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        [WebMethod(EnableSession = true)]
        public void CARD_NO_Delete()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                List<int> listRC = new List<int>();
                string logIDs = Context.Request.Form["C_ID"];

                foreach (string logID in logIDs.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    dbi.BeginTransaction();

                    string sql = @"UPDATE dbo.CARD_NO SET C_DEL=1 WHERE C_ID = @C_ID ";
                    listRC.Add(dbi.ExecNonQuery(sql, CommFunc.InitSqlParam("@C_ID", logID)));

                    if (!listRC.Exists((e) => { return e == 0; }))
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Delete failed, please try again.";
                    }
                }
            }
            catch (Exception ex)
            {
                dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        #endregion

        #region RECORD_MAIN
        [WebMethod(EnableSession = true)]
        public void RECORD_MAIN_Get()
        {
            List<SqlParameter> listParam = new List<SqlParameter>();
            string jsonStr = string.Empty;
            HttpRequest req = Context.Request;
            string strC_ID = req.Form["C_ID"];
            string searchName = req.Form["searchName"];
            string searchVal = req.Form["searchVal"];
            string category = req.Form["category"];
            string sort = req.Form["sort"];
            string page = req.Form["page"] ?? "1";
            string rowsCnt = req.Form["rows"] ?? "100";
            string order = req.Form["order"];
            string sqlWhere = string.Empty;
            if (!string.IsNullOrEmpty(searchVal))
            {
                sqlWhere += string.Format(" AND {0} LIKE '%' + @{0} + '%'", searchName);
                listParam.Add(new SqlParameter("@" + searchName, searchVal));
            }

            if (!string.IsNullOrEmpty(category))
            {
                sqlWhere += " AND C_CATEGORY = @C_CATEGORY";
                listParam.Add(new SqlParameter("@C_CATEGORY", category));
            }

            if (!string.IsNullOrEmpty(strC_ID))
            {
                sqlWhere += " AND C_ID = @C_ID";
                listParam.Add(new SqlParameter("@C_ID", strC_ID));
            }

            Hashtable ht = new Hashtable();
            DB dbi = new DB(SystemConst.DBConnString);
            string sqlBase = @"SELECT * FROM dbo.V_RECORD_MAIN WHERE C_DEL=0";
            string sqlCnt = @"SELECT COUNT(1) FROM dbo.V_RECORD_MAIN WHERE C_DEL=0";
            try
            {
                string sql = sqlBase + sqlWhere;
                sqlCnt += sqlWhere;

                if (!string.IsNullOrEmpty(sort))
                    sql += string.Format(" ORDER BY {0} {1}", sort, order);

                int total = Convert.ToInt16(dbi.ExecScalar(sqlCnt, listParam.ToArray(), "0"));
                DataTable dt = dbi.GetPageData(sql, int.Parse(page), int.Parse(rowsCnt), listParam.ToArray());
                ht.Add("rows", dt);
                ht.Add("total", total);
            }
            catch (Exception ex)
            {
                ht.Add("err", ex.Message);
                if (!ht.ContainsKey("rows"))
                {
                    ht.Add("rows", dbi.GetDataTable(sqlBase + " AND 1=2"));
                }

                ht.Add("total", 0);
            }

            jsonStr = JsonConvert.SerializeObject(ht);
            ResponseWrite(jsonStr);
        }

        [WebMethod(EnableSession = true)]
        public void RECORD_MAIN_Update()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                HttpRequest req = Context.Request;
                RECORD_MAIN entNew = EntityUtilWeb.Create<RECORD_MAIN>(req);

                string sqlInsert = @"INSERT INTO dbo.RECORD_MAIN (
	C_CATEGORY, C_ITD_REF, C_SUPPLIER, C_AGREEMENTNO, C_MAINTENANCE_SERVICE_CONTENT
	, C_MAINTENANCE_COST_CCY, C_MAINTENANCE_COST, C_HYPERLINK, C_REMARK)
OUTPUT Inserted.C_ID
VALUES (@C_CATEGORY, @C_ITD_REF, @C_SUPPLIER, @C_AGREEMENTNO, @C_MAINTENANCE_SERVICE_CONTENT
	, @C_MAINTENANCE_COST_CCY, @C_MAINTENANCE_COST, @C_HYPERLINK, @C_REMARK);";

                string sqlUpdate = @"UPDATE dbo.RECORD_MAIN
SET C_CATEGORY = @C_CATEGORY, C_ITD_REF = @C_ITD_REF, C_SUPPLIER = @C_SUPPLIER
	, C_AGREEMENTNO = @C_AGREEMENTNO, C_MAINTENANCE_SERVICE_CONTENT = @C_MAINTENANCE_SERVICE_CONTENT
    , C_MAINTENANCE_COST_CCY = @C_MAINTENANCE_COST_CCY, C_MAINTENANCE_COST = @C_MAINTENANCE_COST
	, C_HYPERLINK = @C_HYPERLINK, C_REMARK = @C_REMARK
WHERE C_ID = @C_ID";

                List<int> listRC = new List<int>();
                List<SqlParameter> listParam = EntityUtil.GenerateParams<RECORD_MAIN>(entNew);
                dbi.BeginTransaction();

                if (entNew.C_ID <= 0)
                {
                    entNew.C_ID = Convert.ToInt32(dbi.ExecScalar(sqlInsert, listParam.ToArray(), -1));
                    if (entNew.C_ID <= 0)
                    {
                        strResult = "Can not add new item.";
                    }
                }
                else
                {
                    listRC.Add(dbi.ExecNonQuery(sqlUpdate, listParam.ToArray()));
                }

                if (string.IsNullOrEmpty(strResult))
                {
                    bool checkRC = !listRC.Exists((e) => { return e == 0; });
                    if (checkRC)
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Update failed, please try again.";
                    }
                }
                else
                {
                    dbi.AbortTransaction();
                }
            }
            catch (Exception ex)
            {
                if (dbi.IsInTransaction)
                    dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        [WebMethod(EnableSession = true)]
        public void RECORD_MAIN_Delete()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                List<int> listRC = new List<int>();
                string logIDs = Context.Request.Form["C_ID"];

                foreach (string logID in logIDs.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    dbi.BeginTransaction();

                    string sql = @"UPDATE dbo.RECORD_MAIN SET C_DEL=1 WHERE C_ID = @C_ID ";
                    listRC.Add(dbi.ExecNonQuery(sql, CommFunc.InitSqlParam("@C_ID", logID)));

                    if (!listRC.Exists((e) => { return e == 0; }))
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Delete failed, please try again.";
                    }
                }
            }
            catch (Exception ex)
            {
                dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        #endregion

        #region RECORD
        [WebMethod(EnableSession = true)]
        public void RECORD_Get()
        {
            List<SqlParameter> listParam = new List<SqlParameter>();
            string jsonStr = string.Empty;
            HttpRequest req = Context.Request;
            string strC_ID = req.Form["C_ID"];
            string searchName = req.Form["searchName"];
            string searchVal = req.Form["searchVal"];
            string category = req.Form["category"];
            string sort = req.Form["sort"];
            string page = req.Form["page"] ?? "1";
            string rowsCnt = req.Form["rows"] ?? "100";
            string order = req.Form["order"];
            string sqlWhere = string.Empty;
            if (!string.IsNullOrEmpty(searchVal))
            {
                sqlWhere += string.Format(" AND {0} LIKE '%' + @{0} + '%'", searchName);
                listParam.Add(new SqlParameter("@" + searchName, searchVal));
            }

            if (!string.IsNullOrEmpty(category))
            {
                sqlWhere += " AND C_CATEGORY = @C_CATEGORY";
                listParam.Add(new SqlParameter("@C_CATEGORY", category));
            }

            if (!string.IsNullOrEmpty(strC_ID))
            {
                sqlWhere += " AND C_ID = @C_ID";
                listParam.Add(new SqlParameter("@C_ID", strC_ID));
            }

            Hashtable ht = new Hashtable();
            DB dbi = new DB(SystemConst.DBConnString);
            string sqlBase = @"SELECT * FROM dbo.V_RECORD";
            string sqlCnt = @"SELECT COUNT(1) FROM dbo.V_RECORD";
            try
            {
                if (!string.IsNullOrEmpty(sqlWhere))
                    sqlWhere = " WHERE " + sqlWhere.Substring(4);
                string sql = sqlBase + sqlWhere;
                sqlCnt += sqlWhere;

                if (!string.IsNullOrEmpty(sort))
                    sql += string.Format(" ORDER BY {0} {1}", sort, order);

                int total = Convert.ToInt16(dbi.ExecScalar(sqlCnt, listParam.ToArray(), "0"));
                DataTable dt = dbi.GetPageData(sql, int.Parse(page), int.Parse(rowsCnt), listParam.ToArray());
                ht.Add("rows", dt);
                ht.Add("total", total);
            }
            catch (Exception ex)
            {
                ht.Add("err", ex.Message);
                if (!ht.ContainsKey("rows"))
                {
                    ht.Add("rows", dbi.GetDataTable(sqlBase + " WHERE 1=2"));
                }

                ht.Add("total", 0);
            }

            jsonStr = JsonConvert.SerializeObject(ht);
            ResponseWrite(jsonStr);
        }

        [WebMethod(EnableSession = true)]
        public void RECORD_Update()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                HttpRequest req = Context.Request;
                V_RECORD entNew = EntityUtilWeb.Create<V_RECORD>(req);
                //Check ITD_REF Exists
                V_RECORD_MAIN vrm = this.RECORD_MAIN_Get(entNew.C_ITD_REF);
                //Check CARD_NO Exists
                CARD_NO cn = this.CARD_NO_Get(entNew.C_CARDNO);
                if (string.IsNullOrEmpty(vrm.ErrMsg) && string.IsNullOrEmpty(cn.ErrMsg))
                {
                    entNew.C_RECORD_ID = vrm.C_ID;

                    string sqlInsert = @"INSERT INTO dbo.RECORD (C_RECORD_ID, C_AC_NAME_ID, C_ACTUAL_PAY, C_CARDNO, C_START_DATE, C_END_DATE, C_REMARK, C_CCY_ID)
OUTPUT Inserted.C_ID
VALUES (@C_RECORD_ID, @C_AC_NAME_ID, @C_ACTUAL_PAY, @C_CARDNO, @C_START_DATE, @C_END_DATE, @C_REMARK, @C_CCY_ID);";

                    string sqlUpdate = @"UPDATE dbo.RECORD
SET C_RECORD_ID = @C_RECORD_ID, C_AC_NAME_ID = @C_AC_NAME_ID, C_ACTUAL_PAY = @C_ACTUAL_PAY
	, C_CARDNO = @C_CARDNO, C_START_DATE = @C_START_DATE, C_END_DATE = @C_END_DATE, C_REMARK = @C_REMARK
	, C_CCY_ID = @C_CCY_ID
WHERE C_ID = @C_ID";

                    List<int> listRC = new List<int>();
                    List<SqlParameter> listParam = EntityUtil.GenerateParams<V_RECORD>(entNew);
                    bool exist = entNew.C_ID > 0;
                    dbi.BeginTransaction();

                    if (entNew.C_ID <= 0)
                    {
                        entNew.C_ID = Convert.ToInt32(dbi.ExecScalar(sqlInsert, listParam.ToArray(), -1));
                        if (entNew.C_ID <= 0)
                        {
                            strResult = "Can not add new item.";
                        }
                    }
                    else
                    {
                        listRC.Add(dbi.ExecNonQuery(sqlUpdate, listParam.ToArray()));
                    }

                    if (string.IsNullOrEmpty(strResult))
                    {
                        bool checkRC = !listRC.Exists((e) => { return e == 0; });
                        if (checkRC)
                        {
                            dbi.CommitTransaction();
                        }
                        else
                        {
                            dbi.AbortTransaction();
                            strResult = string.Format("{0} failed, please try again.", exist ? "Update" : "Add");
                        }
                    }
                    else
                    {
                        dbi.AbortTransaction();
                    }
                }
                else
                {
                    strResult = vrm.ErrMsg + cn.ErrMsg;
                }
            }
            catch (Exception ex)
            {
                if (dbi.IsInTransaction)
                    dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        [WebMethod(EnableSession = true)]
        public void RECORD_Delete()
        {
            string strResult = string.Empty;
            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                List<int> listRC = new List<int>();
                string logIDs = Context.Request.Form["C_ID"];

                foreach (string logID in logIDs.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    dbi.BeginTransaction();

                    string sql = @"DELETE FROM dbo.RECORD WHERE C_ID = @C_ID ";
                    listRC.Add(dbi.ExecNonQuery(sql, CommFunc.InitSqlParam("@C_ID", logID)));

                    if (!listRC.Exists((e) => { return e == 0; }))
                    {
                        dbi.CommitTransaction();
                    }
                    else
                    {
                        dbi.AbortTransaction();
                        strResult = "Delete failed, please try again.";
                    }
                }
            }
            catch (Exception ex)
            {
                dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            Hashtable ht = new Hashtable();
            ht.Add("msg", strResult);
            ResponseWrite(JsonConvert.SerializeObject(ht));
        }

        #endregion

        private V_RECORD_MAIN RECORD_MAIN_Get(string strITD_REF)
        {
            V_RECORD_MAIN rslt = new V_RECORD_MAIN();
            DB dbi = new DB(SystemConst.DBConnString);
            string sql = @"SELECT * FROM dbo.V_RECORD_MAIN WHERE C_DEL=0 AND C_ITD_REF=@C_ITD_REF";
            try
            {
                DataTable dtMid = dbi.GetDataTable(sql, CommFunc.InitSqlParam("@C_ITD_REF", strITD_REF));
                if (!DataSetHelper.IsEmptyDataTable(dtMid))
                {
                    rslt = EntityUtil.Create<V_RECORD_MAIN>(dtMid.Rows[0]);
                    rslt.ErrMsg = string.Empty;
                }
                else
                {
                    rslt.ErrMsg = string.Format("The ITD REF ({0}) not exists, please check.", strITD_REF);
                }
            }
            catch (Exception ex)
            {
                Log.LogErr(ex);
                rslt = new V_RECORD_MAIN();
                rslt.ErrMsg = ex.Message;
            }

            return rslt;
        }

        private CARD_NO CARD_NO_Get(int? strID)
        {
            CARD_NO rslt = new CARD_NO();
            DB dbi = new DB(SystemConst.DBConnString);
            string sql = @"SELECT * FROM dbo.CARD_NO WHERE C_DEL=0 AND C_ID=@C_ID";
            try
            {
                DataTable dtMid = dbi.GetDataTable(sql, CommFunc.InitSqlParam("@C_ID", strID));
                if (!DataSetHelper.IsEmptyDataTable(dtMid))
                {
                    rslt = EntityUtil.Create<CARD_NO>(dtMid.Rows[0]);
                    rslt.ErrMsg = string.Empty;
                }
                else
                {
                    rslt.ErrMsg = string.Format("The CARD NO ({0}) not exists, please check.", strID);
                }
            }
            catch (Exception ex)
            {
                Log.LogErr(ex);
                rslt = new CARD_NO();
                rslt.ErrMsg = ex.Message;
            }

            return rslt;
        }

        #region Private Methods
        private void ResponseWrite(string msg)
        {
            Context.Response.Clear();
            Context.Response.ContentType = "text/json";
            Context.Response.Write(msg);
        }

        private object CheckNull(object strValue)
        {
            if (strValue == null || string.IsNullOrEmpty(strValue.ToString()))
                return DBNull.Value;
            else
                return strValue;
        }

        private string CheckStrNull(object strValue)
        {
            if (strValue == null || string.IsNullOrEmpty(strValue.ToString()))
                return string.Empty;
            else
                return strValue.ToString();
        }
        #endregion
    }
}
