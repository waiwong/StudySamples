﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using BWHITD.Sys.Common;
using BWHITD.Web.Base;
using WebProj.Modules.Code;

namespace WebProj.Modules.Common
{
    public partial class Main : BaseMasterPage
    {
        protected void Page_Init(object sender, EventArgs e)
        {
            this.SystemTitle.Text = SC.SystemName;
            if (string.IsNullOrEmpty(this.litVersion.Text.Trim()))
            {
                this.litVersion.Text = "Version:" + BWHITD.Sys.Common.SysUtil.GetAssemblyVersion();
            }

            if (string.IsNullOrEmpty(this.litSystemName.Text))
            {
                this.litSystemName.Text = SC.SystemName;
            }

#if DEBUG
            this.litConfig.Text = "[Debug Mode]";
#elif UAT
            this.litConfig.Text = "[UAT Mode]";
#endif

            this.lblUser.Text = "Current User:" + ContextConst.User;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //if (string.IsNullOrEmpty(this.litMainMenu.Text))
                //    this.litMainMenu.Text = this.MainMenu;

                //if (string.IsNullOrEmpty(this.litPageDetail.Text))
                //{
                //    string strCurPath = string.Empty;
                //    string strCurrPathID = CommonFunc.GetReqQueryNoEncrypt(this.Request, "CurrPathID");
                //    if (string.IsNullOrEmpty(strCurrPathID))
                //    {
                //        string requestUrl = this.Page.Request.RawUrl.ToString();
                //        string curPage = requestUrl;
                //        if (!requestUrl.ToLower().StartsWith("/modules") && !requestUrl.ToLower().StartsWith("/page") && !requestUrl.ToLower().StartsWith("/cpmreporting"))
                //            curPage = requestUrl.Substring(requestUrl.Substring(1).IndexOf('/') + 1);

                //        if (curPage.Contains("?"))
                //            curPage = curPage.Substring(0, curPage.IndexOf("?"));

                //        strCurPath = this.GetCurrPathByIDorRawUrl(curPage);
                //    }
                //    else
                //    {
                //        strCurPath = this.GetCurrPathByIDorRawUrl(strCurrPathID);
                //    }

                //    if (string.IsNullOrEmpty(strCurPath) || strCurPath.ToLower().Equals("default"))
                //    {
                //        this.litPageDetail.Text = string.Empty;
                //    }
                //    else
                //    {
                //        this.litPageDetail.Text = string.Format("<span style=\"font-weight:bold;\">Current Path:</span>{0}",
                //            strCurPath);
                //    }
                //}
            }

            if (string.IsNullOrEmpty(this.hfBaseUrl.Value))
                this.hfBaseUrl.Value = this.ResolveUrl("~/Modules/");
        }

        private string GetCurrPathByIDorRawUrl(string strIDorRawUrl)
        {
            string strCurrPath = string.Empty;
            if (!string.IsNullOrEmpty(strIDorRawUrl) && CheckValueOfSession("CurrPathDIC"))
            {
                if (this.DicCurrPath.ContainsKey(strIDorRawUrl))
                {
                    strCurrPath = this.DicCurrPath[strIDorRawUrl];
                }
            }

            return strCurrPath;
        }

        private string MainMenu
        {
            get
            {
                if (!CheckValueOfSession("MainMenu"))
                {
                    //SetValutToSession<string>("MainMenu", this.GetMenuStringForEasyUI());
                    SetValutToSession<string>("MainMenu", this.GetMenuStringForBootstrap());
                }

                return GetValueFromSession<string>("MainMenu");
            }
            set
            {
                SetValutToSession<string>("MainMenu", value);
            }
        }

        private Dictionary<string, string> DicCurrPath
        {
            get
            {
                return GetValueFromSession<Dictionary<string, string>>("CurrPathDIC");
            }
            set
            {
                SetValutToSession<Dictionary<string, string>>("CurrPathDIC", value);
            }
        }

        #region EasyUI
        private string GetMenuStringForEasyUI()
        {
            Dictionary<string, string> dicCurrPath = new Dictionary<string, string>();
            DataTable dtMenu = new DataTable();
            using (DB dbi = new DB(SystemConst.DBConnString))
            {
                string sql = string.Format(@"SELECT b.Name_ID, b.Related_Menu, b.Name_Detail, ISNULL(b.ParentID, 0) AS ParentID, b.Target
	,CASE WHEN EXISTS (
			SELECT * FROM dbo.BWH_ITD_PERMISSION_NAME a	WHERE a.ParentID = b.Name_ID
			) THEN '1' ELSE '0' END AS HasChild
FROM dbo.BWH_ITD_PERMISSION_NAME b
WHERE b.IsEnable = 1 AND b.Visible = 1 AND b.Name_ID IN (
		SELECT Name_ID FROM dbo.BWH_ITD_PERMISSION_RIGHT
		WHERE IsRight = 1 AND User_GroupID IN (
				SELECT User_GroupID FROM dbo.BWH_ITD_PERMISSION_GROUP WHERE IsEnable = 1 AND User_Group IN ('{0}')))
ORDER BY b.ParentID, b.SortID", ContextConst.Group.Replace(",", "','"));
                dtMenu = dbi.GetDataTable(sql);
            }

            StringBuilder sbResult = this.AddNodesEasyUI(ref dicCurrPath, dtMenu);
            this.DicCurrPath = dicCurrPath;
            return sbResult.ToString();
        }

        private StringBuilder AddNodesEasyUI(ref Dictionary<string, string> dicCurrPath, DataTable dtMenu)
        {
            StringBuilder sbResult = new StringBuilder();
            StringBuilder sbChild = new StringBuilder();
            DataView dvMenu = dtMenu.DefaultView;
            dvMenu.RowFilter = "ParentID = 0";
            if (dvMenu.Count == 1)
            {
                if (string.IsNullOrEmpty(dvMenu[0]["Related_Menu"].ToString()))
                {
                    string strParentID0 = dvMenu[0]["Name_ID"].ToString();
                    DataRow drRemove = null;
                    for (int i = 0; i < dtMenu.Rows.Count; i++)
                    {
                        if (dtMenu.Rows[i]["Name_ID"].ToString().Equals(strParentID0))
                            drRemove = dtMenu.Rows[i];

                        if (dtMenu.Rows[i]["ParentID"].ToString().Equals(strParentID0))
                            dtMenu.Rows[i]["ParentID"] = 0;
                    }

                    if (drRemove != null)
                        dtMenu.Rows.Remove(drRemove);
                }
            }

            //Promote the sencondary menu that only has 1 child to first menu
            foreach (DataRowView drMenuRow in dvMenu)
            {
                if (string.IsNullOrEmpty(drMenuRow["Related_Menu"].ToString()))
                {
                    string strParentID0 = drMenuRow["Name_ID"].ToString();
                    if (dtMenu.Select(string.Format("ParentID = {0}", strParentID0)).Length == 1)
                    {
                        DataRow drRemove = null;
                        for (int i = 0; i < dtMenu.Rows.Count; i++)
                        {
                            if (dtMenu.Rows[i]["Name_ID"].ToString().Equals(strParentID0))
                                drRemove = dtMenu.Rows[i];

                            if (dtMenu.Rows[i]["ParentID"].ToString().Equals(strParentID0))
                                dtMenu.Rows[i]["ParentID"] = 0;
                        }

                        if (drRemove != null)
                            dtMenu.Rows.Remove(drRemove);
                    }
                }
            }

            string strNameID, strTitle, strUrl;
            int iTarget;
            bool hasChild = false;

            foreach (DataRowView itemRow in dvMenu)
            {
                strNameID = itemRow["Name_ID"].ToString();
                strTitle = itemRow["Name_Detail"].ToString();
                strUrl = itemRow["Related_Menu"].ToString();
                iTarget = Convert.ToInt16(itemRow["Target"]);
                hasChild = itemRow["HasChild"].ToString().EndsWith("1");

                if (ContextConst.IsBCP && iTarget >= 5)
                    continue;

                if (iTarget >= 5)
                    iTarget -= 5;
                //Target: 0 normal; 1 OpenNewWindowsMax; 2 OpenNewWinByAjax;3 OpenNewWinMaxByAjax 
                //        +5 Unavailable in BCP

                if (hasChild)
                {
                    sbResult.AppendFormat("<a href=\"javascript:void(0)\" class=\"easyui-menubutton\" data-options=\"menu:'#mm{0}'\">{1}</a>",
                        strNameID, strTitle);
                    sbChild.Append(this.AddFirstChildNodesEasyUI(ref dicCurrPath, dtMenu, strTitle, strNameID));
                }
                else
                {
                    if (iTarget == 2)
                    {
                        strUrl = string.Format("javascript:OpenNewWinByAjax('{0}')", strTitle);
                    }
                    else if (iTarget == 3)
                    {
                        strUrl = string.Format("javascript:OpenNewWinMaxByAjax('{0}')", strTitle);
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(strUrl))
                        {
                            if (!dicCurrPath.ContainsKey(strUrl))
                                dicCurrPath.Add(strUrl, strTitle);
                            strUrl = this.ResolveUrl("~" + strUrl);
                            if (iTarget == 1)
                            {
                                strUrl = string.Format("javascript:OpenNewWindowsMax('{0}')", strUrl);
                            }
                        }

                        if (!strUrl.StartsWith("javascript"))
                            strUrl += string.Format("{0}CurrPathID={1}", strUrl.Contains("?") ? "&" : "?", strNameID);
                        if (!dicCurrPath.ContainsKey(strNameID))
                            dicCurrPath.Add(strNameID, strTitle);
                    }

                    sbResult.AppendFormat("<a href=\"{0}\" class=\"easyui-linkbutton\" data-options=\"plain:true\">{1}</a>", strUrl, strTitle);
                }
            }

            sbResult.Insert(0, "<div class=\"easyui-panel\" style=\"padding: 5px;\">").Append("</div>").Append(sbChild);
            return sbResult;
        }

        private StringBuilder AddFirstChildNodesEasyUI(ref Dictionary<string, string> dicCurrPath, DataTable dtMenu,
            string parentTitle, string parentID)
        {
            StringBuilder sbChildResult = new StringBuilder();
            DataView dvMenu = dtMenu.DefaultView;
            dvMenu.RowFilter = "ParentID = '" + parentID + "'";

            string strNameID, strTitle, strUrl, strCurPath;
            int iTarget;
            bool hasChild = false;

            foreach (DataRowView itemRow in dvMenu)
            {
                strNameID = itemRow["Name_ID"].ToString();
                strTitle = itemRow["Name_Detail"].ToString();
                strUrl = itemRow["Related_Menu"].ToString();
                iTarget = Convert.ToInt16(itemRow["Target"]);

                if (ContextConst.IsBCP && iTarget >= 5)
                    continue;

                if (iTarget >= 5)
                    iTarget -= 5;

                strCurPath = string.Format("{0} >> {1}", parentTitle, strTitle);
                hasChild = itemRow["HasChild"].ToString().EndsWith("1");
                if (hasChild)
                {
                    StringBuilder sbSecondChild = this.AddSecondChildNodesEasyUI(ref dicCurrPath, dtMenu, strCurPath, strNameID);
                    sbChildResult.AppendFormat("<div><span>{0}</span><div>{1}</div></div>", strTitle, sbSecondChild.ToString());
                }
                else
                {
                    if (iTarget == 2)
                    {
                        strUrl = string.Format("javascript:OpenNewWinByAjax('{0}')", strTitle);
                    }
                    else if (iTarget == 3)
                    {
                        strUrl = string.Format("javascript:OpenNewWinMaxByAjax('{0}')", strTitle);
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(strUrl))
                        {
                            if (!dicCurrPath.ContainsKey(strUrl))
                                dicCurrPath.Add(strUrl, strCurPath);
                            strUrl = this.ResolveUrl("~" + strUrl);
                            if (iTarget == 1)
                            {
                                strUrl = string.Format("javascript:OpenNewWindowsMax('{0}')", strUrl);
                            }
                        }
                    }

                    if (!strUrl.StartsWith("javascript"))
                        strUrl += string.Format("{0}CurrPathID={1}", strUrl.Contains("?") ? "&" : "?", strNameID);

                    if (!dicCurrPath.ContainsKey(strNameID))
                        dicCurrPath.Add(strNameID, strCurPath);

                    //sbChildResult.AppendFormat("<div><a href=\"{0}\" class=\"easyui-linkbutton\" data-options=\"plain:true\">{1}</a></div>", strUrl, strTitle);
                    sbChildResult.AppendFormat("<div data-options=\"plain:true\" onclick=\"GoToUrl('{0}')\">{1}</div>", strUrl, strTitle);
                }
            }

            sbChildResult.Insert(0, string.Format("<div id=\"mm{0}\" style=\"width: 150px;display: none\">", parentID)).Append("</div>");
            return sbChildResult;
        }

        private StringBuilder AddSecondChildNodesEasyUI(ref Dictionary<string, string> dicCurrPath, DataTable dtMenu,
            string parentTitle, string parentID)
        {
            StringBuilder sbResult = new StringBuilder();
            DataView dvMenu = dtMenu.DefaultView;
            dvMenu.RowFilter = "ParentID = '" + parentID + "'";
            string strTitle, strUrl, strCurPath, strNameID;
            int iTarget;

            foreach (DataRowView itemRow in dvMenu)
            {
                strNameID = itemRow["Name_ID"].ToString();
                strTitle = itemRow["Name_Detail"].ToString();
                iTarget = Convert.ToInt16(itemRow["Target"]);
                if (ContextConst.IsBCP && iTarget >= 5)
                    continue;

                if (iTarget >= 5)
                    iTarget -= 5;

                strCurPath = string.Format("{0} >> {1}", parentTitle, strTitle);
                if (iTarget == 2)
                {
                    strUrl = string.Format("javascript:OpenNewWinByAjax('{0}')", strTitle);
                }
                else if (iTarget == 3)
                {
                    strUrl = string.Format("javascript:OpenNewWinMaxByAjax('{0}')", strTitle);
                }
                else
                {
                    strUrl = itemRow["Related_Menu"].ToString();
                    if (!string.IsNullOrEmpty(strUrl))
                    {
                        if (!dicCurrPath.ContainsKey(strUrl))
                            dicCurrPath.Add(strUrl, strCurPath);
                        strUrl = this.ResolveUrl("~" + strUrl);
                        if (iTarget == 1)
                        {
                            strUrl = string.Format("javascript:OpenNewWindowsMax('{0}')", strUrl);
                        }
                    }
                }

                if (!strUrl.StartsWith("javascript"))
                    strUrl += string.Format("{0}CurrPathID={1}", strUrl.Contains("?") ? "&" : "?", strNameID);

                if (!dicCurrPath.ContainsKey(strNameID))
                    dicCurrPath.Add(strNameID, strCurPath);

                //sbResult.AppendFormat("<div><a href=\"{0}\" class=\"easyui-linkbutton\" data-options=\"plain:true\">{1}</a></div>", strUrl, strTitle);
                sbResult.AppendFormat("<div data-options=\"plain:true\" onclick=\"GoToUrl('{0}')\">{1}</div>", strUrl, strTitle);
            }

            return sbResult;
        }
        #endregion

        #region Bootstrap
        private string GetMenuStringForBootstrap()
        {
            Dictionary<string, string> dicCurrPath = new Dictionary<string, string>();
            DataTable dtMenu = new DataTable();
            using (DB dbi = new DB(SystemConst.DBConnString))
            {
                string sql = string.Format(@"SELECT b.Name_ID, b.Related_Menu, b.Name_Detail, ISNULL(b.ParentID, 0) AS ParentID, b.Target
	,CASE WHEN EXISTS (
			SELECT * FROM dbo.BWH_ITD_PERMISSION_NAME a	WHERE a.ParentID = b.Name_ID
			) THEN '1' ELSE '0' END AS HasChild
FROM dbo.BWH_ITD_PERMISSION_NAME b
WHERE b.IsEnable = 1 AND b.Visible = 1 AND b.Name_ID IN (
		SELECT Name_ID FROM dbo.BWH_ITD_PERMISSION_RIGHT
		WHERE IsRight = 1 AND User_GroupID IN (
				SELECT User_GroupID FROM dbo.BWH_ITD_PERMISSION_GROUP WHERE IsEnable = 1 AND User_Group IN ('{0}')))
ORDER BY b.ParentID, b.SortID", ContextConst.Group.Replace(",", "','"));
                dtMenu = dbi.GetDataTable(sql);
            }

            StringBuilder sbResult = this.AddNodesBootstrap(ref dicCurrPath, dtMenu);
            this.DicCurrPath = dicCurrPath;
            return string.Format("<div class=\"navbar\"><div class=\"navbar-inner\">"
                + "<ul class=\"nav\">{0}</ul></div></div>", sbResult.ToString());
        }

        private StringBuilder AddNodesBootstrap(ref Dictionary<string, string> dicCurrPath, DataTable dtMenu)
        {
            StringBuilder sbResult = new StringBuilder();
            DataView dvMenu = dtMenu.DefaultView;
            dvMenu.RowFilter = "ParentID = 0";
            if (dvMenu.Count == 1)
            {
                if (string.IsNullOrEmpty(dvMenu[0]["Related_Menu"].ToString()))
                {
                    string strParentID0 = dvMenu[0]["Name_ID"].ToString();
                    DataRow drRemove = null;
                    for (int i = 0; i < dtMenu.Rows.Count; i++)
                    {
                        if (dtMenu.Rows[i]["Name_ID"].ToString().Equals(strParentID0))
                            drRemove = dtMenu.Rows[i];

                        if (dtMenu.Rows[i]["ParentID"].ToString().Equals(strParentID0))
                            dtMenu.Rows[i]["ParentID"] = 0;
                    }

                    if (drRemove != null)
                        dtMenu.Rows.Remove(drRemove);
                }
            }

            //Promote the sencondary menu that only has 1 child to first menu
            foreach (DataRowView drMenuRow in dvMenu)
            {
                if (string.IsNullOrEmpty(drMenuRow["Related_Menu"].ToString()))
                {
                    string strParentID0 = drMenuRow["Name_ID"].ToString();
                    if (dtMenu.Select(string.Format("ParentID = {0}", strParentID0)).Length == 1)
                    {
                        DataRow drRemove = null;
                        for (int i = 0; i < dtMenu.Rows.Count; i++)
                        {
                            if (dtMenu.Rows[i]["Name_ID"].ToString().Equals(strParentID0))
                                drRemove = dtMenu.Rows[i];

                            if (dtMenu.Rows[i]["ParentID"].ToString().Equals(strParentID0))
                                dtMenu.Rows[i]["ParentID"] = 0;
                        }

                        if (drRemove != null)
                            dtMenu.Rows.Remove(drRemove);
                    }
                }
            }

            string strNameID, strTitle, strUrl;
            int iTarget;
            bool hasChild = false;

            foreach (DataRowView itemRow in dvMenu)
            {
                strNameID = itemRow["Name_ID"].ToString();
                strTitle = itemRow["Name_Detail"].ToString();
                strUrl = itemRow["Related_Menu"].ToString();
                iTarget = Convert.ToInt16(itemRow["Target"]);
                hasChild = itemRow["HasChild"].ToString().EndsWith("1");

                if (ContextConst.IsBCP && iTarget >= 5)
                    continue;

                if (iTarget >= 5)
                    iTarget -= 5;
                //Target: 0 normal; 1 OpenNewWindowsMax; 2 OpenNewWinByAjax;3 OpenNewWinMaxByAjax 
                //        +5 Unavailable in BCP
                if (hasChild)
                {
                    sbResult.AppendFormat("<li class=\"dropdown\"><a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">{0}"
                        + "<b class=\"caret\"></b></a><ul class=\"dropdown-menu fixed-menu\">", strTitle);
                    sbResult.Append(this.AddFirstChildNodesBootstrap(ref dicCurrPath, dtMenu, strTitle, strNameID).ToString());
                    sbResult.Append("</ul></li>");
                }
                else
                {
                    if (iTarget == 2)
                    {
                        strUrl = string.Format("javascript:OpenNewWinByAjax('{0}')", strTitle);
                    }
                    else if (iTarget == 3)
                    {
                        strUrl = string.Format("javascript:OpenNewWinMaxByAjax('{0}')", strTitle);
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(strUrl))
                        {
                            if (!dicCurrPath.ContainsKey(strUrl))
                                dicCurrPath.Add(strUrl, strTitle);
                            strUrl = this.ResolveUrl("~" + strUrl);
                            if (iTarget == 1)
                            {
                                strUrl = string.Format("javascript:OpenNewWindowsMax('{0}')", strUrl);
                            }
                        }

                        if (!strUrl.StartsWith("javascript"))
                            strUrl += string.Format("{0}CurrPathID={1}", strUrl.Contains("?") ? "&" : "?", strNameID);
                        if (!dicCurrPath.ContainsKey(strNameID))
                            dicCurrPath.Add(strNameID, strTitle);
                    }

                    sbResult.AppendFormat("<li><a href=\"{0}\">{1}</a></li>", strUrl, strTitle);
                }
            }

            return sbResult;
        }

        private StringBuilder AddFirstChildNodesBootstrap(ref Dictionary<string, string> dicCurrPath, DataTable dtMenu,
            string parentTitle, string parentID)
        {
            StringBuilder sbChildResult = new StringBuilder();
            DataView dvMenu = dtMenu.DefaultView;
            dvMenu.RowFilter = "ParentID = '" + parentID + "'";

            string strNameID, strTitle, strUrl, strCurPath;
            int iTarget;
            bool hasChild = false;

            foreach (DataRowView itemRow in dvMenu)
            {
                strNameID = itemRow["Name_ID"].ToString();
                strTitle = itemRow["Name_Detail"].ToString();
                strUrl = itemRow["Related_Menu"].ToString();
                iTarget = Convert.ToInt16(itemRow["Target"]);

                if (ContextConst.IsBCP && iTarget >= 5)
                    continue;

                if (iTarget >= 5)
                    iTarget -= 5;

                strCurPath = string.Format("{0} >> {1}", parentTitle, strTitle);
                hasChild = itemRow["HasChild"].ToString().EndsWith("1");
                if (hasChild)
                {
                    StringBuilder sbSecondChild = this.AddSecondChildNodesBootstrap(ref dicCurrPath, dtMenu, strCurPath, strNameID);
                    sbChildResult.AppendFormat("<li class=\"dropdown-submenu\"><a>{0}</a><ul class=\"dropdown-menu\">{1}</ul></li>",
                        strTitle, sbSecondChild.ToString());
                }
                else
                {
                    if (iTarget == 2)
                    {
                        strUrl = string.Format("javascript:OpenNewWinByAjax('{0}')", strTitle);
                    }
                    else if (iTarget == 3)
                    {
                        strUrl = string.Format("javascript:OpenNewWinMaxByAjax('{0}')", strTitle);
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(strUrl))
                        {
                            if (!dicCurrPath.ContainsKey(strUrl))
                                dicCurrPath.Add(strUrl, strCurPath);
                            strUrl = this.ResolveUrl("~" + strUrl);
                            if (iTarget == 1)
                            {
                                strUrl = string.Format("javascript:OpenNewWindowsMax('{0}')", strUrl);
                            }
                        }
                    }

                    if (!strUrl.StartsWith("javascript"))
                        strUrl += string.Format("{0}CurrPathID={1}", strUrl.Contains("?") ? "&" : "?", strNameID);

                    if (!dicCurrPath.ContainsKey(strNameID))
                        dicCurrPath.Add(strNameID, strCurPath);

                    sbChildResult.AppendFormat("<li><a href=\"{0}\">{1}</a></li>", strUrl, strTitle);
                }
            }

            return sbChildResult;
        }

        private StringBuilder AddSecondChildNodesBootstrap(ref Dictionary<string, string> dicCurrPath, DataTable dtMenu,
            string parentTitle, string parentID)
        {
            StringBuilder sbResult = new StringBuilder();
            DataView dvMenu = dtMenu.DefaultView;
            dvMenu.RowFilter = "ParentID = '" + parentID + "'";
            string strTitle, strUrl, strCurPath, strNameID;
            int iTarget;

            foreach (DataRowView itemRow in dvMenu)
            {
                strNameID = itemRow["Name_ID"].ToString();
                strTitle = itemRow["Name_Detail"].ToString();
                iTarget = Convert.ToInt16(itemRow["Target"]);
                if (ContextConst.IsBCP && iTarget >= 5)
                    continue;

                if (iTarget >= 5)
                    iTarget -= 5;

                strCurPath = string.Format("{0} >> {1}", parentTitle, strTitle);
                if (iTarget == 2)
                {
                    strUrl = string.Format("javascript:OpenNewWinByAjax('{0}')", strTitle);
                }
                else if (iTarget == 3)
                {
                    strUrl = string.Format("javascript:OpenNewWinMaxByAjax('{0}')", strTitle);
                }
                else
                {
                    strUrl = itemRow["Related_Menu"].ToString();
                    if (!string.IsNullOrEmpty(strUrl))
                    {
                        if (!dicCurrPath.ContainsKey(strUrl))
                            dicCurrPath.Add(strUrl, strCurPath);
                        strUrl = this.ResolveUrl("~" + strUrl);
                        if (iTarget == 1)
                        {
                            strUrl = string.Format("javascript:OpenNewWindowsMax('{0}')", strUrl);
                        }
                    }
                }

                if (!strUrl.StartsWith("javascript"))
                    strUrl += string.Format("{0}CurrPathID={1}", strUrl.Contains("?") ? "&" : "?", strNameID);

                if (!dicCurrPath.ContainsKey(strNameID))
                    dicCurrPath.Add(strNameID, strCurPath);

                sbResult.AppendFormat("<li><a href=\"{0}\">{1}</a></li>", strUrl, strTitle);
            }

            return sbResult;
        }
        #endregion
    }
}
