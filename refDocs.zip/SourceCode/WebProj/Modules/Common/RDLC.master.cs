﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BWHITD.Sys.Common;
using BWHITD.Web.Base;
using Microsoft.Reporting.WebForms;

namespace WebProj.Modules.Common
{
    public partial class RDLC : BaseMasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void smMain_AsyncPostBackError(object sender, AsyncPostBackErrorEventArgs e)
        {
            this.smMain.AsyncPostBackErrorMessage = e.Exception.Message;
        }

        public void showRpt(string rptName, DataTable dtResult, Dictionary<string, string> dicParams)
        {
            Dictionary<string, DataTable> dicDSResult = new Dictionary<string, DataTable>();
            dicDSResult.Add("dsMain", dtResult);
            this.showRpt(rptName, dicDSResult, dicParams);
        }

        public void showRpt(string rptName, Dictionary<string, DataTable> dicDSResult, Dictionary<string, string> dicParams)
        {
            this.rptViewer.Reset();
            this.rptViewer.ProcessingMode = Microsoft.Reporting.WebForms.ProcessingMode.Local;
            this.rptViewer.LocalReport.ReportPath = Server.MapPath(this.ResolveUrl(string.Format("~/Modules/RptRDLC/{0}.rdlc", rptName)));
            this.rptViewer.LocalReport.DataSources.Clear();

            foreach (KeyValuePair<string, DataTable> item in dicDSResult)
            {
                ReportDataSource rptDSResult = new ReportDataSource();
                rptDSResult.Name = item.Key;
                rptDSResult.Value = item.Value;
                this.rptViewer.LocalReport.DataSources.Add(rptDSResult);
            }

            List<ReportParameter> rpParams = new List<ReportParameter>();

            foreach (KeyValuePair<string, string> item in dicParams)
            {
                rpParams.Add(new ReportParameter(item.Key, item.Value));
            }

            if (rpParams.Count > 0)
                this.rptViewer.LocalReport.SetParameters(rpParams.ToArray());

            this.rptViewer.LocalReport.Refresh();
            CommonFunc.ExecuteClientScript("HideBlockUI();");
        }
    }
}
