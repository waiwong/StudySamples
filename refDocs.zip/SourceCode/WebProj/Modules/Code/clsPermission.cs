﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using BWHITD.Sys.Common;
using BWHITD.Web.Base;

namespace WebProj.Modules.Code
{
    public class Permission
    {
        /// <summary>
        /// Y: Allow to view information of all records
        /// N: Allow to view information of current user.
        /// </summary>
        public bool ALL_RECORD { get; set; }        

        public Permission()
        {
            using (DB dbi = new DB(SystemConst.DBConnString))
            {
                string sql = string.Format(@"SELECT a.Name_Detail, ISNULL(d.IsRight, 0) AS IsRight
FROM dbo.BWH_ITD_PERMISSION_NAME a
LEFT JOIN (
	SELECT b.Name_ID, b.IsRight
	FROM dbo.BWH_ITD_PERMISSION_RIGHT b
	INNER JOIN dbo.BWH_ITD_PERMISSION_GROUP c ON c.IsEnable = 1 AND c.User_GroupID = b.
		User_GroupID AND c.User_Group IN ('{0}')
	) d ON d.Name_ID = a.Name_ID
WHERE a.IsEnable = 1 AND ISNULL(d.IsRight, 0) = 1 AND ISNULL(Related_Menu, '') = ''", ContextConst.Group.Replace(",", "','"));
                using (SqlDataReader sqlDR = dbi.GetDataReader(sql))
                {
                    while (sqlDR.Read())
                    {
                        string strKey = sqlDR["Name_Detail"].ToString().ToUpper().Trim();
                        switch (strKey)
                        {
                            case "ALL_RECORD":
                                this.ALL_RECORD = sqlDR["IsRight"].ToString().Equals("1");
                                break;
                        }
                    }
                }
            }
        }
    }
}
