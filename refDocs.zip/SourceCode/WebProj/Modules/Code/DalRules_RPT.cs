﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using BWHITD.Sys.Common;

namespace WebProj.Modules.Code
{
    public sealed partial class DAL : IDisposable
    {
        #region Initialize
        private static readonly DAL Instance = new DAL();

        private DB dbi;
        private DAL()
        {
            this.dbi = new DB(SystemConst.DBConnParam);
        }

        public static DAL INS
        {
            get
            {
                return Instance;
            }
        }
        #endregion

        #region Dispose / Destructor
        public void Dispose()
        {
            // Dispose of remaining objects.
            if (this.dbi != null)
            {
                this.dbi.Dispose();
            }
        }
        #endregion

        private SqlParameter[] GetListParamFromDic(Dictionary<string, string> dicParams)
        {
            List<SqlParameter> listParam = new List<SqlParameter>();
            foreach (KeyValuePair<string, string> item in dicParams)
            {
                //if (item.Key.ToUpper().StartsWith("C_"))
                listParam.Add(new SqlParameter("@" + item.Key, item.Value));
            }

            return listParam.ToArray();
        }

        public DataTable RPT_CHECKING(Dictionary<string, string> dicParams)
        {
            //@MAKER AS NVARCHAR(10)
            string prcName = "dbo.P_RPT_CHECKING";
            return this.dbi.GetDataTableSP(prcName, this.GetListParamFromDic(dicParams));
        }

        public DataTable RPT_GET_CHEQUE_DATA_HIST(Dictionary<string, string> dicParams)
        {
            //@GENERATE_DATE AS DATETIME
            string prcName = "dbo.P_RPT_GET_CHEQUE_DATA_HIST";
            return this.dbi.GetDataTableSP(prcName, this.GetListParamFromDic(dicParams));
        }

        public string RPT_CLEAN_DATA(string strUser)
        {
            string strResult = string.Empty;

            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                string sqlInsert = @"DELETE FROM dbo.CHEQUE_DATA_HIST WHERE DATEDIFF(DAY, C_GENERATE_TIME, GETDATE()) = 0;
INSERT INTO dbo.CHEQUE_DATA_HIST (C_LOGID, C_ACC_NO, C_CHEQUE_NO, C_CCY, C_AMT, C_MAKER, C_MAKER_TIME, C_GENERATOR)
SELECT C_LOGID, C_ACC_NO, C_CHEQUE_NO, C_CCY, C_AMT, C_MAKER, C_MAKER_TIME, @GENERATOR
FROM dbo.CHEQUE_DATA
ORDER BY C_LOGID";
                string sqlDelete = @"DELETE FROM dbo.CHEQUE_DATA;";
                List<SqlParameter> listParam = new List<SqlParameter>();
                listParam.Add(new SqlParameter("@GENERATOR", strUser));

                dbi.BeginTransaction();
                dbi.ExecNonQuery(sqlInsert, listParam.ToArray());
                dbi.ExecNonQuery(sqlDelete);
                dbi.CommitTransaction();
            }
            catch (Exception ex)
            {
                if (dbi.IsInTransaction)
                    dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            return strResult;
        }

        public string RPT_RELOAD_CHEQUE_DATA_HIST(DateTime dtGenerateDate, string strUser)
        {
            string strResult = string.Empty;

            DB dbi = new DB(SystemConst.DBConnParam);
            try
            {
                string sqlInsert = @"INSERT INTO dbo.CHEQUE_DATA (C_ACC_NO, C_CHEQUE_NO, C_CCY, C_AMT, C_MAKER, C_MAKER_TIME)
                                     SELECT C_ACC_NO, C_CHEQUE_NO, C_CCY, C_AMT, C_MAKER, C_MAKER_TIME
                                     FROM dbo.CHEQUE_DATA_HIST
                                     WHERE DATEDIFF(DAY, C_GENERATE_TIME, @GenerateDate) = 0 ORDER BY C_LOGID;
                                     INSERT INTO dbo.CHEQUE_DATA_RELOAD (C_LOGID, C_ACC_NO, C_CHEQUE_NO, C_CCY, C_AMT, C_MAKER, C_MAKER_TIME,
                                        C_GENERATOR, C_GENERATE_TIME, C_RELOADOR)
                                     SELECT C_LOGID, C_ACC_NO, C_CHEQUE_NO, C_CCY, C_AMT, C_MAKER, C_MAKER_TIME, 
                                        C_GENERATOR, C_GENERATE_TIME, @C_RELOADOR
                                     FROM dbo.CHEQUE_DATA_HIST
                                     WHERE DATEDIFF(DAY, C_GENERATE_TIME, @GenerateDate) = 0
                                     ORDER BY C_LOGID;";

                string sqlDelete = @"DELETE FROM dbo.CHEQUE_DATA;";
                string sqlUpdate = @"DELETE FROM dbo.CHEQUE_DATA_HIST WHERE DATEDIFF(DAY, C_GENERATE_TIME, @GenerateDate) = 0";

                List<SqlParameter> listParam = new List<SqlParameter>();
                listParam.Add(new SqlParameter("@GenerateDate", dtGenerateDate.ToYMD()));
                listParam.Add(new SqlParameter("@C_RELOADOR", strUser));

                dbi.BeginTransaction();
                dbi.ExecNonQuery(sqlDelete);
                dbi.ExecNonQuery(sqlInsert, listParam.ToArray());
                dbi.ExecNonQuery(sqlUpdate, listParam.ToArray());
                dbi.CommitTransaction();
            }
            catch (Exception ex)
            {
                if (dbi.IsInTransaction)
                    dbi.AbortTransaction();
                Log.LogErr(ex);
                strResult = ex.Message;
            }

            return strResult;
        }
    }
}
