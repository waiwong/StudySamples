﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;

namespace WebProj.Modules.Code
{
    public partial class V_RECORD_MAIN
    {
        public string ErrMsg { get; set; }
    }

    public partial class CARD_NO
    {
        public string ErrMsg { get; set; }
    }

    //public partial class SUPPLIER
    //{
    //    public List<SqlParameter> GenerateParams()
    //    {
    //        List<SqlParameter> lstParam = new List<SqlParameter>();
    //        PropertyInfo[] piList = this.GetType().GetProperties();
    //        for (int i = 0; i < piList.Length; i++)
    //        {
    //            string srcName = piList[i].Name;
    //            if (!srcName.StartsWith("C_"))
    //                continue;
    //            if (piList[i].CanWrite)
    //                lstParam.Add(new SqlParameter("@" + srcName, CommFunc.CheckNull(piList[i].GetValue(this, null))));
    //        }

    //        return lstParam;
    //    }
    //}
}