﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using BWHITD.Sys.Common;

namespace WebProj.Modules.Code
{
    internal static class CommFunc
    {
        /// <summary>
        /// Init only One SqlParamter
        /// </summary>
        /// <param name="paramName">parameter Name</param>
        /// <param name="paramValue">paramter value</param>
        /// <returns></returns>
        public static SqlParameter[] InitSqlParam(string paramName, object paramValue)
        {
            SqlParameter[] resultParam = new SqlParameter[1];
            resultParam[0] = new SqlParameter(paramName, paramValue);
            return resultParam;
        }

        public static object CheckNull(object strValue)
        {
            if (strValue == null || string.IsNullOrEmpty(strValue.ToString()))
                return DBNull.Value;
            else
                return strValue;
        }

        public static IEnumerable<T> EnumToList<T>()
        {
            Type enumType = typeof(T);

            // Can't use generic type constraints on value types,
            // so have to do check like this
            if (enumType.BaseType != typeof(Enum))
                throw new ArgumentException("T must be of type System.Enum");

            Array enumValArray = Enum.GetValues(enumType);
            List<T> enumValList = new List<T>(enumValArray.Length);

            foreach (int val in enumValArray)
            {
                enumValList.Add((T)Enum.Parse(enumType, val.ToString()));
            }

            return enumValList;
        }

        /// <summary>
        /// Get Dictionary of T, key T,value:  Description
        /// </summary>
        /// <typeparam name="T">Genric Type</typeparam>
        /// <returns></returns>
        public static Dictionary<T, string> EnumToDic<T>()
        {
            Type enumType = typeof(T);

            // Can't use generic type constraints on value types,
            // so have to do check like this
            if (enumType.BaseType != typeof(Enum))
                throw new ArgumentException("T must be of type System.Enum");

            Array enumValArray = Enum.GetValues(enumType);

            Dictionary<T, string> enumDic = new Dictionary<T, string>(enumValArray.Length);

            foreach (int val in enumValArray)
            {
                T enumIns = val.ToEnum<T>();

                DescriptionAttribute attribute = enumIns.GetType()
                .GetField(enumIns.ToString())
                .GetCustomAttributes(typeof(DescriptionAttribute), false)
                .SingleOrDefault() as DescriptionAttribute;

                enumDic.Add(enumIns, attribute == null ? enumIns.ToString() : attribute.Description);
            }

            return enumDic;
        }

        /// <summary>
        ///  Get Dictionary of T, key T,value:  Description 
        /// </summary>
        /// <typeparam name="T">Genric Type</typeparam>
        /// <param name="filterBoolAttr">only return match fiter item</param>
        /// <returns></returns>
        public static Dictionary<T, string> EnumToDic<T>(bool filterBoolAttr)
        {
            Type enumType = typeof(T);
            if (enumType.BaseType != typeof(Enum))
                throw new ArgumentException("T must be of type System.Enum");

            Array enumValArray = Enum.GetValues(enumType);

            Dictionary<T, string> enumDic = new Dictionary<T, string>(enumValArray.Length);

            foreach (int val in enumValArray)
            {
                T enumIns = val.ToEnum<T>();

                DescriptionAttribute attribute = enumIns.GetType().GetField(enumIns.ToString())
                    .GetCustomAttributes(typeof(DescriptionAttribute), false)
                    .SingleOrDefault() as DescriptionAttribute;

                BoolAttr bAttr = enumIns.GetType().GetField(enumIns.ToString())
                    .GetCustomAttributes(typeof(BoolAttr), false)
                    .SingleOrDefault() as BoolAttr;
                if (bAttr.B_Value == filterBoolAttr)
                    enumDic.Add(enumIns, attribute == null ? enumIns.ToString() : attribute.Description);
            }

            return enumDic;
        }

        /// <summary>
        /// Get List of EnumClass T
        /// </summary>
        /// <typeparam name="T">Genric Type</typeparam>
        /// <returns></returns>
        public static List<EnumClass<T>> EnumToListClass<T>()
        {
            Type enumType = typeof(T);
            if (enumType.BaseType != typeof(Enum))
                throw new ArgumentException("T must be of type System.Enum");

            Array enumValArray = Enum.GetValues(enumType);

            SortedList<int, EnumClass<T>> enumResult = new SortedList<int, EnumClass<T>>();

            foreach (int val in enumValArray)
            {
                T enumIns = val.ToEnum<T>();

                DescriptionAttribute attribute = enumIns.GetType().GetField(enumIns.ToString())
                    .GetCustomAttributes(typeof(DescriptionAttribute), false)
                    .SingleOrDefault() as DescriptionAttribute;

                BoolAttr bAttr = enumIns.GetType().GetField(enumIns.ToString())
                    .GetCustomAttributes(typeof(BoolAttr), false)
                    .SingleOrDefault() as BoolAttr;
                EnumClass<T> midIns = new EnumClass<T>();
                if (attribute != null)
                    midIns.DisplayAttrVal = attribute.Description;
                else
                    midIns.DisplayAttrVal = enumIns.ToString();
                if (bAttr != null)
                    midIns.BoolAttrVal = bAttr.B_Value;
                midIns.IntVal = Convert.ToInt32(enumIns);
                midIns.EnumIns = enumIns;
                enumResult.Add(midIns.IntVal, midIns);
            }

            return enumResult.Values.ToList<EnumClass<T>>();
        }
    }

    public class EnumClass<T>
    {
        public bool BoolAttrVal { get; set; }
        public string DisplayAttrVal { get; set; }
        public T EnumIns { get; set; }
        public int IntVal { get; set; }
    }

    internal class DisplayAttr : Attribute
    {
        public DisplayAttr(string descrition_in)
        {
            this.description = descrition_in;
        }

        protected string description;
        public string Description
        {
            get
            {
                return this.description;
            }
        }
    }

    internal class BoolAttr : Attribute
    {
        public BoolAttr(bool pValue)
        {
            this.bValue = pValue;
        }

        protected bool bValue;
        public bool B_Value
        {
            get
            {
                return this.bValue;
            }
        }
    }
}
