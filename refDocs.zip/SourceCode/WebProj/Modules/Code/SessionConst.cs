﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using BWHITD.Web.Base;

namespace WebProj.Modules.Code
{
    public class SC
    {
        protected const string SessionPrefix = "ITD_CCAS_WebProj_";
        public static string SystemName
        {
            get
            {
                string strKey = SessionPrefix + "SystemName";
                if (!SessionHelper.CheckValueOfSession(strKey))
                {
                    Assembly currAssembley = Assembly.GetExecutingAssembly();
                    string strName = ((AssemblyProductAttribute)Attribute.GetCustomAttribute(currAssembley, typeof(AssemblyProductAttribute))).Product;

                    SessionHelper.SetValutToSession<string>(strKey, strName);
                }

                return SessionHelper.GetValueFromSession<string>(strKey);
            }
        }

        public static Permission PermissionIns
        {
            get
            {
                string strKey = SessionPrefix + "Permission";
                if (!SessionHelper.CheckValueOfSession(strKey))
                {
                    SessionHelper.SetValutToSession<Permission>(strKey, new Permission());
                }

                return SessionHelper.GetValueFromSession<Permission>(strKey);
            }
        }
    }
}
