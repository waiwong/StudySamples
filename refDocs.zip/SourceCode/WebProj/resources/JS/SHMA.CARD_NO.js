﻿/// <reference path="jquery.min.js" />
/// <reference path="_MyFunction.js" />
/// <reference path="jquery.easyui.min.js" />
/// <reference path="SHMA.Common.js" />

var unEditMsg = "Can not modify.";
var unDeleteMsg = "Can not delete.";
var unSelectMsg = "Please select records!";
var editOneMsg = "Please select only one records!";
var cfmDelMsg = "Please confirm to delete?";

var grid = $("#grid");
var sch = $('#searchBox');

var frmMain = $("#frmMain");
var btnOK = $('#btnOK');
var btnCancel = $('#btnCancel');

$(function () {
    //init DataTable plugin
    grid.datagrid({
        url: ParseUrl("Ajax/Controller.asmx/CARD_NO_Get"),
        toolbar: "#toolbar",
        pagination: true,
        pageSize: 20,
        pageList: [10, 20, 50, 100, 200],
        beforePageText: '',
        afterPageText: '/{pages}',
        displayMsg: '{from} - {to}({total})',
        columns: [[
                { field: 'chk', checkbox: true },
                { field: 'C_CATNO', title: 'CATNO', width: 20, sortable: true, resizable: true },
                { field: 'C_ID', title: 'CARD NO', sortable: true, resizable: true, width: 40 },
                { field: 'C_SERIALNO', title: 'SERIALNO', sortable: true, resizable: true, width: 80 },
                { field: 'C_EQUIPMENT', title: 'EQUIPMENT', sortable: true, resizable: true, width: 200 },
                { field: 'C_ITD_REF', title: 'ITD_REF', sortable: true, resizable: true, width: 80 },
                { field: 'C_DEPARTMENT', title: 'DEPARTMENT', sortable: true, resizable: true, width: 80 },
                { field: 'C_VENDOR', title: 'VENDOR', sortable: true, resizable: true, width: 120 },
                { field: 'C_DN_NO', title: 'DN_NO', sortable: true, resizable: true, width: 90 },
                { field: 'C_WARRANTY', title: 'WARRANTY', sortable: true, resizable: true, width: 90 },
                { field: 'C_START_DATE', title: 'START DAY', width: 80, align: 'right', sortable: true, resizable: true },
                { field: 'C_END_DATE', title: 'END DAY', width: 80, align: 'right', sortable: true, resizable: true },
                { field: 'C_TYPE', title: 'TYPE', sortable: true, resizable: true, width: 30 },
                { field: 'C_EQUIPMENT_COST', title: 'EQUIPMENT COST', width: 80, sortable: true },
                { field: 'C_DELIVERY_DATE', title: 'DELIVERY_DATE', width: 80, align: 'right', sortable: true, resizable: true },
                { field: 'C_BUY_MAINTENANCE', title: 'BUY_MAINTENANCE', width: 80, sortable: true }
        ]]
        , onDblClickRow: function (index, row) { EditRecord(row.C_ID) }
        , onLoadError: function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); }
        , onLoadSuccess: function (json) { ShowMsgJson(json); }
    });

    InitDateMask($('.DatetimeOpt'));
    InitValidateboxWidth($(".RequireBox"));
    InitNumberbox($(".NumberClass2"), 2, 105);
    IntiComboCARDNO_VENDOR($("#ddlC_VENDOR"));
    IntiComboCARDNO_EQUIPMENT($('#ddlC_EQUIPMENT'), true);

    //Search Box
    sch.searchbox({
        menu: '#shMenu',
        searcher: function (val, name) { grid.datagrid('load', { searchName: name, searchVal: val }); }
    });

    //Create New Button
    $('#lnkNew').click(function () {
        $('#pnlResult').panel('close');
        $('#pnlMain').panel('open');
        $('#pnlMain').panel('setTitle', 'New');
        $("#id_C_CATNO").focus();
        frmMain.form('reset');
        DisableFormValidation(frmMain);
        $("#id_C_ID").val(-1);
    });

    //Delete Button
    $("#lnkDelete").click(function () {
        var rows = grid.datagrid('getSelections');
        if (rows.length > 0) {
            var logids = [];
            $.each(rows, function (idx, obj) {
                logids.push(obj.C_ID);
            });

            $.messager.confirm('Confirm', cfmDelMsg, function (r) {
                if (r) {
                    $.ajax({
                        type: 'POST',
                        data: { C_ID: logids.toString() },
                        url: ParseUrl('Ajax/Controller.asmx/CARD_NO_Delete')
                    }).done(function (json) { if (ShowMsgJson(json)) { ReloadGrid(); } })
                        .fail(function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); });
                }
            });
        }
        else { ShowMsg(2, unSelectMsg); }
    });

    //Reload Grid
    function CloseAndReloadGrid() { $('#pnlMain').panel('close'); $('#pnlResult').panel('open'); ReloadGrid(); }
    function ReloadGrid() { grid.datagrid('reload'); }

    EnterToTab(frmMain, UpdateRecords);
    //Edit Button
    $("#lnkEdit").click(function () {
        var rows = grid.datagrid('getSelections');
        var cnt = rows.length;
        if (cnt == 1) { EditRecord(rows[0].C_ID, false); }
        else if (cnt > 1) { ShowMsg(2, editOneMsg); }
        else if (cnt == 0) { ShowMsg(2, unSelectMsg); }
    });

    $("#lnkClone").click(function () {
        var rows = grid.datagrid('getSelections');
        var cnt = rows.length;
        if (cnt == 1) { EditRecord(rows[0].C_ID, true); }
        else if (cnt > 1) { ShowMsg(2, editOneMsg); }
        else if (cnt == 0) { ShowMsg(2, unSelectMsg); }
    });

    function EditRecord(keyNo, cloneRecord) {
        $.ajax({
            type: 'POST',
            data: { C_ID: keyNo },
            url: ParseUrl('Ajax/Controller.asmx/CARD_NO_Get')
        }).done(function (json) {
            if (ShowMsgJson(json)) {
                $('#pnlResult').panel('close');
                $('#pnlMain').panel('open');
                frmMain.form('load', json.rows[0]);
                if (cloneRecord) { $("#id_C_ID").val(-1); $('#pnlMain').panel('setTitle', 'Clone'); }
                else { $('#pnlMain').panel('setTitle', 'Edit'); }
                $("#id_C_CATNO").focus();
            }
        }).fail(function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); });
    }

    btnOK.click(function () { UpdateRecords(); });
    btnCancel.click(function () { $('#pnlMain').panel('close'); $('#pnlResult').panel('open'); });
    function UpdateRecords() { DoSubmit(frmMain, ParseUrl("Ajax/Controller.asmx/CARD_NO_Update"), null, true, null, CloseAndReloadGrid); }
    //init form
    DisableFormValidation(frmMain);
    $('#pnlMain').css('display', 'block');
});