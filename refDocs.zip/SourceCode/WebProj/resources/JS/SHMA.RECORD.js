﻿/// <reference path="jquery.min.js" />
/// <reference path="_MyFunction.js" />
/// <reference path="jquery.easyui.min.js" />
/// <reference path="SHMA.Common.js" />

var unEditMsg = "Can not modify.";
var unDeleteMsg = "Can not delete.";
var unSelectMsg = "Please select records!";
var editOneMsg = "Please select only one records!";
var cfmDelMsg = "Please confirm to delete?";

var grid = $("#grid");
var sch = $('#searchBox');

var frmMain = $("#frmMain");
var btnOK = $('#btnOK');
var btnCancel = $('#btnCancel');

$(function () {
    var strC_ITD_REF = getParameterByName('C_ITD_REF');
    //init DataTable plugin
    grid.datagrid({
        url: ParseUrl("Ajax/Controller.asmx/RECORD_Get"),
        toolbar: "#toolbar",
        pagination: true,
        pageSize: 20,
        queryParams: { searchName: 'C_ITD_REF', searchVal: strC_ITD_REF },
        pageList: [10, 20, 50, 100, 200],
        beforePageText: '',
        afterPageText: '/{pages}',
        displayMsg: '{from} - {to}({total})',
        columns: [[
                { field: 'ck', checkbox: true },
	            { field: 'C_ID', hidden: true },
                { field: 'C_ITD_REF', title: 'ITD REF', width: 80, sortable: true },
                { field: 'C_EQUIPMENT', title: 'EQUIPMENT', width: 80, sortable: true },
                { field: 'C_CCY_NAME', title: 'CURRENCY', width: 80, sortable: true },
                { field: 'C_ACTUAL_PAY', title: 'ACTUAL PAY', width: 80, sortable: true },
                { field: 'C_SERIALNO', title: 'SERIALNO', width: 80, sortable: true },
                { field: 'C_CATNO', title: 'CATNO', width: 80, sortable: true },
                { field: 'C_CARDNO', title: 'CARDNO', width: 80, sortable: true },
                { field: 'C_START_DATE', title: 'START DATE', width: 80, sortable: true },
                { field: 'C_END_DATE', title: 'END DATE', width: 80, sortable: true },
                { field: 'C_REMIND_DATE', title: 'REMIND DATE', width: 80, sortable: true },
                { field: 'C_MONTHLY_COST', title: 'MONTHLY COST', width: 80, sortable: true, hidden: true },
                { field: 'C_TOTAL_MONTH', title: 'TOTAL MONTH', width: 80, sortable: true, hidden: true },
                { field: 'C_EQUIPMENT_COST', title: 'EQUIPMENT COST', width: 80, sortable: true, hidden: true },
                { field: 'C_DELIVERY_DATE', title: 'DELIVERY DATE', width: 80, sortable: true, hidden: true },
                { field: 'C_AC_NAME', title: 'AC NAME', width: 80, sortable: true, hidden: true },
                { field: 'C_AC_SHORTNAME', title: 'AC SHORTNAME', width: 80, sortable: true },
                { field: 'C_AGREEMENTNO', title: 'AGREEMENTNO', width: 80, sortable: true, hidden: true },
                { field: 'C_CATEGORY_NAME', title: 'CATEGORY NAME', width: 80, sortable: true },
                { field: 'C_SUPPLIER_NAME', title: 'SUPPLIER NAME', width: 80, sortable: true, hidden: true },
                { field: 'C_SUPPLIER_SHORTNAME', title: 'SUPPLIER SHORTNAME', width: 80, sortable: true },
                { field: 'C_CONTACT_PERSON', title: 'CONTACT PERSON', width: 80, sortable: true },
                { field: 'C_PHONE', title: 'PHONE', width: 80, sortable: true, hidden: true },
                { field: 'C_FAX', title: 'FAX', width: 80, sortable: true, hidden: true },
                { field: 'C_EMAIL', title: 'EMAIL', width: 80, sortable: true, hidden: true },
                { field: 'C_VENDOR', title: 'VENDOR', width: 80, sortable: true, hidden: true },
                { field: 'C_ADDRESS', title: 'ADDRESS', width: 80, sortable: true, hidden: true },
                { field: 'C_REMARK', title: 'REMARK', width: 80, sortable: true }
        ]]
        , onDblClickRow: function (index, row) { EditRecord(row.C_ID) }
        , onLoadError: function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); }
        , onLoadSuccess: function (json) { ShowMsgJson(json); }
    });

    $('[name=C_ITD_REF]').mask("REF99-99-99");
    InitDateMask($('.DatetimeOpt'));
    InitValidateboxWidth($(".RequireBox"));
    IntiComboCat($('#ddlC_CATEGORY_SEARCH'), false);
    IntiComboAC_NAME($('#ddlC_AC_NAME_ID'));
    IntiComboCCY($('#ddlC_CCY_ID'));
    IntiComboCARDNO($('#ddlC_CARDNO'));
    InitNumberbox($(".NumberClass2"), 2, 105);

    $("#ckbDetail").change(function () {
        var hiddenColumns = "C_MONTHLY_COST,C_TOTAL_MONTH,C_AGREEMENTNO, C_EQUIPMENT_COST,C_DELIVERY_DATE,C_AC_NAME,C_SUPPLIER_NAME,C_PHONE,C_FAX,C_EMAIL,C_ADDRESS,C_VENDOR".split(',');
        var action = "showColumn";
        if (!this.checked) action = "hideColumn";
        $.each(hiddenColumns, function (i, val) { grid.datagrid(action, val); });
    });

    $("#ddlC_CATEGORY_SEARCH").combobox({
        onSelect: CallSearch
        , loadFilter: function (data) {
            var opts = $(this).combobox('options');
            var emptyRow = {};
            emptyRow[opts.valueField] = '';
            emptyRow[opts.textField] = '--ALL--';
            data.unshift(emptyRow);
            return data;
        }
    });

    //Search Box
    sch.searchbox({
        menu: '#shMenu',
        searcher: function (val, name) {
            var categoryID = $('#ddlC_CATEGORY_SEARCH').combobox('getValue');
            grid.datagrid('load', { searchName: name, searchVal: val, category: categoryID });
        }
    });

    //$("#lnkSearch").click(CallSearch);

    function CallSearch() {
        var name = sch.searchbox('getName');
        var val = sch.searchbox('getValue');
        var categoryID = $('#ddlC_CATEGORY_SEARCH').combobox('getValue');
        grid.datagrid('load', { searchName: name, searchVal: val, category: categoryID });
    }

    //Create New Button
    $('#lnkNew').click(function () {
        $('#pnlResult').panel('close');
        $('#pnlMain').panel('open');
        $('#pnlMain').panel('setTitle', 'New');
        $("#id_C_ITD_REF").focus();
        frmMain.form('reset');
        DisableFormValidation(frmMain);
        $("#id_C_ID").val(-1);
    });

    //Delete Button
    $("#lnkDelete").click(function () {
        var rows = grid.datagrid('getSelections');
        if (rows.length > 0) {
            var logids = [];
            $.each(rows, function (idx, obj) {
                logids.push(obj.C_ID);
            });

            $.messager.confirm('Confirm', cfmDelMsg, function (r) {
                if (r) {
                    $.ajax({
                        type: 'POST',
                        data: { C_ID: logids.toString() },
                        url: ParseUrl('Ajax/Controller.asmx/RECORD_Delete')
                    }).done(function (json) { if (ShowMsgJson(json)) { ReloadGrid(); } })
                        .fail(function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); });
                }
            });
        }
        else { ShowMsg(2, unSelectMsg); }
    });

    //Reload Grid
    function CloseAndReloadGrid() { $('#pnlMain').panel('close'); $('#pnlResult').panel('open'); ReloadGrid(); }
    function ReloadGrid() { grid.datagrid('reload'); }
    EnterToTab(frmMain, UpdateRecords);
    //Edit Button
    $("#lnkEdit").click(function () {
        var rows = grid.datagrid('getSelections');
        var cnt = rows.length;
        if (cnt == 1) { EditRecord(rows[0].C_ID); }
        else if (cnt > 1) { ShowMsg(2, editOneMsg); }
        else if (cnt == 0) { ShowMsg(2, unSelectMsg); }
    });

    $("#lnkClone").click(function () {
        var rows = grid.datagrid('getSelections');
        var cnt = rows.length;
        if (cnt == 1) { EditRecord(rows[0].C_ID, true); }
        else if (cnt > 1) { ShowMsg(2, editOneMsg); }
        else if (cnt == 0) { ShowMsg(2, unSelectMsg); }
    });

    function EditRecord(keyNo, cloneRecord) {
        $.ajax({
            type: 'POST',
            data: { C_ID: keyNo },
            url: ParseUrl('Ajax/Controller.asmx/RECORD_Get')
        }).done(function (json) {
            if (ShowMsgJson(json)) {
                $('#pnlResult').panel('close');
                $('#pnlMain').panel('open');
                frmMain.form('load', json.rows[0]);
                if (cloneRecord) { $("#id_C_ID").val(-1); $('#pnlMain').panel('setTitle', 'Clone'); }
                else { $('#pnlMain').panel('setTitle', 'Edit'); }
                $("#id_C_ITD_REF").focus();
            }
        }).fail(function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); });
    }

    //Dialog Buttons Event
    btnOK.click(function () { UpdateRecords(); });
    btnCancel.click(function () { $('#pnlMain').panel('close'); $('#pnlResult').panel('open'); });
    function UpdateRecords() { DoSubmit(frmMain, ParseUrl("Ajax/Controller.asmx/RECORD_Update"), null, true, null, CloseAndReloadGrid); }
    //init form
    DisableFormValidation(frmMain);
    $('#pnlMain').css('display', 'block');
});