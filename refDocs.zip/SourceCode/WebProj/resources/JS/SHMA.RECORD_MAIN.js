﻿/// <reference path="jquery.min.js" />
/// <reference path="_MyFunction.js" />
/// <reference path="jquery.easyui.min.js" />
/// <reference path="SHMA.Common.js" />

var unEditMsg = "Can not modify.";
var unDeleteMsg = "Can not delete.";
var unSelectMsg = "Please select records!";
var editOneMsg = "Please select only one records!";
var cfmDelMsg = "Please confirm to delete?";

var grid = $("#grid");
var sch = $('#searchBox');

var frmMain = $("#frmMain");
var btnOK = $('#btnOK');
var btnCancel = $('#btnCancel');

$(function () {
    //init DataTable plugin
    grid.datagrid({
        url: ParseUrl("Ajax/Controller.asmx/RECORD_MAIN_Get"),
        toolbar: "#toolbar",
        pagination: true,
        pageSize: 20,
        pageList: [10, 20, 50, 100, 200],
        beforePageText: '',
        afterPageText: '/{pages}',
        displayMsg: '{from} - {to}({total})'
        , columns: [[
            { field: 'ck', checkbox: true, rowspan: 2 },
	        { field: 'C_ID', hidden: true, rowspan: 2 },
            {
                field: 'C_ITD_REF', title: 'ITD REF', rowspan: 2, width: 80, sortable: true, resizable: true,
                formatter: function (value, row, index) {
                    return '<a href="RECORD.aspx?C_ITD_REF=' + value + '" class="easyui-linkbutton easyui-tips" tooltip="VIEW RECORD DETAIL" width="80px" plain="true" ;">' + value + '</a> ';
                }
            },

	        { field: 'C_CATEGORY_NAME', title: 'CATEGORY', rowspan: 2, width: 150, sortable: true, resizable: true },
            { title: 'MAINTENANCE PERIOD', colspan: 2 },
	        { field: 'C_SUPPLIER_NAME', title: 'SUPPLIER', rowspan: 2, width: 80, sortable: true, resizable: true },
	        { field: 'C_AGREEMENTNO', title: 'AGREEMENTNO', rowspan: 2, width: 80, sortable: true, resizable: true },
	        { field: 'C_CONTACT_PERSON', title: 'CONTACT<br />PERSON', rowspan: 2, width: 80, sortable: true, resizable: true },
	        { field: 'C_MAINTENANCE_SERVICE_CONTENT', title: 'MAINTENANCE<br />SERVICE CONTENT', rowspan: 2, width: 80, sortable: true, resizable: true },
            { field: 'C_MAINTENANCE_COST_CCY_NAME', title: 'MAINTENANCE<br />CURRENCY', rowspan: 2, width: 80, sortable: true, resizable: true },
            { field: 'C_MAINTENANCE_COST', title: 'MAINTENANCE<br />COST', rowspan: 2, width: 80, sortable: true, resizable: true },
            { field: 'C_HYPERLINK', title: 'HYPERLINK', rowspan: 2, width: 80, hidden: true },
	        { field: 'C_PHONE', title: 'PHONE', rowspan: 2, width: 80, hidden: true },
	        { field: 'C_FAX', title: 'FAX', rowspan: 2, width: 80, hidden: true },
	        { field: 'C_EMAIL', title: 'EMAIL', rowspan: 2, width: 80, hidden: true },
	        { field: 'C_ADDRESS', title: 'ADDRESS', rowspan: 2, width: 80, hidden: true },
            { field: 'C_REMARK', title: 'REMARK', rowspan: 2, width: 80, sortable: true, resizable: true }
        ], [
            { field: 'C_START_DAY', title: 'START DAY', width: 80, align: 'right', sortable: true, resizable: true },
            { field: 'C_END_DAY', title: 'END DAY', width: 80, align: 'right', sortable: true, resizable: true }
        ]]
        , onDblClickRow: function (index, row) { EditRecord(row.C_ID) }
        , onLoadError: function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); }
        , onLoadSuccess: function (json) { ShowMsgJson(json); }
    });

    $('[name=C_ITD_REF]').mask("REF99-99-99");
    InitValidateboxWidth($(".RequireBox"));
    IntiComboCat($('#ddlC_CATEGORY'), true);
    IntiComboCat($('#ddlC_CATEGORY_SEARCH'), false);
    IntiComboSupplier($("#ddlC_SUPPLIER"));
    IntiComboCCY($('#ddlC_MAINTENANCE_COST_CCY'));

    $("#ckbDetail").change(function () {
        var hiddenColumns = "C_HYPERLINK,C_PHONE,C_FAX,C_EMAIL,C_ADDRESS".split(',');
        var action = "showColumn";
        if (!this.checked) action = "hideColumn";
        $.each(hiddenColumns, function (i, val) { grid.datagrid(action, val); });
    });

    $("#ddlC_CATEGORY_SEARCH").combobox({
        onSelect: CallSearch
        , loadFilter: function (data) {
            var opts = $(this).combobox('options');
            var emptyRow = {};
            emptyRow[opts.valueField] = '';
            emptyRow[opts.textField] = '--ALL--';
            data.unshift(emptyRow);
            return data;
        }
    });

    //Search Box
    sch.searchbox({
        menu: '#shMenu',
        searcher: function (val, name) {
            var categoryID = $('#ddlC_CATEGORY_SEARCH').combobox('getValue');
            grid.datagrid('load', { searchName: name, searchVal: val, category: categoryID });
        }
    });

    $("#lnkSearch").click(CallSearch);

    function CallSearch() {
        var name = sch.searchbox('getName');
        var val = sch.searchbox('getValue');
        var categoryID = $('#ddlC_CATEGORY_SEARCH').combobox('getValue');
        grid.datagrid('load', { searchName: name, searchVal: val, category: categoryID });
    }

    //Create New Button
    $('#lnkNew').click(function () {
        $('#pnlResult').panel('close');
        $('#pnlMain').panel('open');
        $('#pnlMain').panel('setTitle', 'New');
        $("#id_C_ITD_REF").focus();
        frmMain.form('reset');
        DisableFormValidation(frmMain);
        $("#id_C_ID").val(-1);
    });

    //Delete Button
    $("#lnkDelete").click(function () {
        var rows = grid.datagrid('getSelections');
        if (rows.length > 0) {
            var logids = [];
            $.each(rows, function (idx, obj) {
                logids.push(obj.C_ID);
            });

            $.messager.confirm('Confirm', cfmDelMsg, function (r) {
                if (r) {
                    $.ajax({
                        type: 'POST',
                        data: { C_ID: logids.toString() },
                        url: ParseUrl('Ajax/Controller.asmx/RECORD_MAIN_Delete')
                    }).done(function (json) { if (ShowMsgJson(json)) { ReloadGrid(); } })
                        .fail(function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); });
                }
            });
        }
        else { ShowMsg(2, unSelectMsg); }
    });

    //Reload Grid
    function CloseAndReloadGrid() { $('#pnlMain').panel('close'); $('#pnlResult').panel('open'); ReloadGrid(); }
    function ReloadGrid() { grid.datagrid('reload'); }

    EnterToTab(frmMain, UpdateRecords);
    //Edit Button
    $("#lnkEdit").click(function () {
        var rows = grid.datagrid('getSelections');
        var cnt = rows.length;
        if (cnt == 1) { EditRecord(rows[0].C_ID, false); }
        else if (cnt > 1) { ShowMsg(2, editOneMsg); }
        else if (cnt == 0) { ShowMsg(2, unSelectMsg); }
    });

    $("#lnkClone").click(function () {
        var rows = grid.datagrid('getSelections');
        var cnt = rows.length;
        if (cnt == 1) { EditRecord(rows[0].C_ID, true); }
        else if (cnt > 1) { ShowMsg(2, editOneMsg); }
        else if (cnt == 0) { ShowMsg(2, unSelectMsg); }
    });

    function EditRecord(keyNo, cloneRecord) {
        $.ajax({
            type: 'POST',
            data: { C_ID: keyNo },
            url: ParseUrl('Ajax/Controller.asmx/RECORD_MAIN_Get')
        }).done(function (json) {
            if (ShowMsgJson(json)) {
                $('#pnlResult').panel('close');
                $('#pnlMain').panel('open');
                frmMain.form('load', json.rows[0]);
                if (cloneRecord) { $("#id_C_ID").val(-1); $('#pnlMain').panel('setTitle', 'Clone'); }
                else { $('#pnlMain').panel('setTitle', 'Edit'); }
                $("#id_C_ITD_REF").focus();
            }
        }).fail(function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); });
    }

    btnOK.click(function () { UpdateRecords(); });
    btnCancel.click(function () { $('#pnlMain').panel('close'); $('#pnlResult').panel('open'); });
    function UpdateRecords() { DoSubmit(frmMain, ParseUrl("Ajax/Controller.asmx/RECORD_MAIN_Update"), null, true, null, CloseAndReloadGrid); }
    //init form
    DisableFormValidation(frmMain);
    $('#pnlMain').css('display', 'block');
});