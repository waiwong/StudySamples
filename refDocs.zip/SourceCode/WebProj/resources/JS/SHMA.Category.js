﻿/// <reference path="jquery.min.js" />
/// <reference path="_MyFunction.js" />
/// <reference path="jquery.easyui.min.js" />

var unEditMsg = "Can not modify.";
var unDeleteMsg = "Can not delete.";
var unSelectMsg = "Please select records!";
var editOneMsg = "Please select only one records!";
var cfmDelMsg = "Please confirm to delete?";

var grid = $("#grid");
var sch = $('#searchBox');
var frmAdd = $("#frmAdd");
var dlgAdd = $("#dlgAdd");
var txtC_NAME = $("#txtC_NAME");

var dlgEdit = $("#dlgEdit");
var frmEdit = $("#frmEdit");
var dlgBtns = $('#dlg-buttons');
var btnOK = $('#btnOK');
var btnNew = $('#btnNew');
var btnCancel = $('#btnCancel');
var txtC_ID_EDIT = $("#txtC_ID_EDIT");
var txtC_NAME_EDIT = $("#txtC_NAME_EDIT");

$(function () {
    dlgEdit.dialog({
        top: 150,
        width: 400,
        height: 200,
        modal: true,
        closed: true,
        buttons: dlgBtns
    });

    //init DataTable plugin
    grid.datagrid({
        url: ParseUrl("Ajax/Controller.asmx/CATEGORY_Get"),
        toolbar: "#toolbar",
        columns: [[
                    { field: 'chk', checkbox: true },
                    { field: 'C_ID', title: 'No.', sortable: true, resizable: true, width: 50 },
                    { field: 'C_NAME', title: 'NAME', sortable: true, resizable: true, width: 350 }
        ]],
        onDblClickRow: function (index, row) {EditRecord(row.C_ID);},
        onLoadError: function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); }
        , onLoadSuccess: function (json) { ShowMsgJson(json); }
    });

    InitValidatebox(txtC_NAME);
    InitValidatebox(txtC_NAME_EDIT);

    ////Search Box
    //sch.searchbox({
    //    menu: '#shMenu',
    //    searcher: function (val, name) { grid.datagrid('load', { C_CCY: ccy.val(), searchName: name, searchVal: val }); }
    //});
    btnNew.click(function () { DoSubmit(frmAdd, ParseUrl("Ajax/Controller.asmx/CATEGORY_Update"), null, true, null, ReloadGrid); });
    EnterToSubmit(frmAdd, function () { DoSubmit(frmAdd, ParseUrl("Ajax/Controller.asmx/CATEGORY_Update"), null, true, null, ReloadGrid); });
    //Delete Button
    $("#lnkDelete").click(function () {
        var rows = grid.datagrid('getSelections');
        if (rows.length > 0) {
            var logids = [];
            $.each(rows, function (idx, obj) {
                logids.push(obj.C_ID);
            });

            $.messager.confirm('Confirm', cfmDelMsg, function (r) {
                if (r) {
                    $.ajax({
                        type: 'POST',
                        data: { C_ID: logids.toString() },
                        url: ParseUrl('Ajax/Controller.asmx/CATEGORY_Delete')
                    }).done(function (json) { if (ShowMsgJson(json)) { ReloadGrid(); } })
                        .fail(function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); });
                }
            });
        }
        else { ShowMsg(2, unSelectMsg); }
    });

    //Reload Grid
    function ReloadGrid() { grid.datagrid('reload'); txtC_NAME.focus(); }
    $("#lnkRefresh").click(ReloadGrid);

    EnterToSubmit(frmEdit, UpdateRecords);
    //Edit Button
    $("#lnkEdit").click(function () {
        var rows = grid.datagrid('getSelections');
        var cnt = rows.length;
        if (cnt == 1) {
            var keyNo = rows[0].C_ID;
            EditRecord(keyNo);
        }
        else if (cnt > 1) { ShowMsg(2, editOneMsg); }
        else if (cnt == 0) { ShowMsg(2, unSelectMsg); }
    });

    function EditRecord(keyNo) {
        $.ajax({
            type: 'POST',
            data: { C_ID: keyNo },
            url: ParseUrl('Ajax/Controller.asmx/CATEGORY_Get')
        }).done(function (json) {
            if (ShowMsgJson(json)) {
                frmEdit.form('load', json.rows[0]);
                ShowDialog(dlgEdit, 'Edit');
                txtC_NAME_EDIT.focus();
            }
        }).fail(function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); });
    }

    //Dialog Buttons Event
    btnOK.click(function () { UpdateRecords(); });
    btnCancel.click(function () { dlgEdit.dialog('close'); });
    function UpdateRecords() { DoSubmit(frmEdit, ParseUrl("Ajax/Controller.asmx/CATEGORY_Update"), null, true, dlgEdit, ReloadGrid); }
    txtC_NAME.focus();
    //init form
    DisableFormValidation(frmAdd);
    DisableFormValidation(frmEdit);
});