﻿/// <reference path="jquery.min.js" />
/// <reference path="_MyFunction.js" />
/// <reference path="jquery.easyui.min.js" />

var unEditMsg = "Can not modify.";
var unDeleteMsg = "Can not delete.";
var unSelectMsg = "Please select records!";
var editOneMsg = "Please select only one records!";
var cfmDelMsg = "Please confirm to delete?";

var grid = $("#grid");
var sch = $('#searchBox');

var lnkNew = $('#lnkNew');
var dlgMain = $("#dlgMain");
var frmMain = $("#frmMain");
var dlgBtns = $('#dlg-buttons');
var btnOK = $('#btnOK');
var btnCancel = $('#btnCancel');

$(function () {
    dlgMain.dialog({
        top: 150,
        width: 550,
        height: 400,
        modal: true,
        closed: true,
        buttons: dlgBtns
    });

    //init DataTable plugin
    grid.datagrid({
        url: ParseUrl("Ajax/Controller.asmx/SUPPLIER_Get"),
        toolbar: "#toolbar",
        pagination: true,
        pageSize: 20,
        pageList: [10, 20, 50, 100, 200],
        beforePageText: '',
        afterPageText: '/{pages}',
        displayMsg: '{from} - {to}({total})',
        columns: [[
                { field: 'chk', checkbox: true },
                { field: 'C_ID', title: 'No.', sortable: true, resizable: true, width: 40 },
                { field: 'C_NAME', title: 'NAME', sortable: true, resizable: true, width: 350 },
                { field: 'C_SHORTNAME', title: 'SHORTNAME', sortable: true, resizable: true, width: 100 },
                { field: 'C_CONTACT_PERSON', title: 'CONTACT PERSON', sortable: true, resizable: true, width: 120 },
                { field: 'C_PHONE', title: 'PHONE', sortable: true, resizable: true, width: 120 },
                { field: 'C_FAX', title: 'FAX', sortable: true, resizable: true, width: 120 },
                { field: 'C_EMAIL', title: 'EMAIL', sortable: true, resizable: true, width: 120 },
                { field: 'C_ADDRESS', title: 'ADDRESS', sortable: true, resizable: true, width: 200 }
        ]]
        , onDblClickRow: function (index, row) { EditRecord(row.C_ID) }
        , onLoadError: function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); }
        , onLoadSuccess: function (json) { ShowMsgJson(json); }
    });

    //Search Box
    sch.searchbox({
        menu: '#shMenu',
        searcher: function (val, name) { grid.datagrid('load', { searchName: name, searchVal: val }); }
    });

    //Create New Button
    lnkNew.click(function () {
        ShowDialog(dlgMain, 'New');
        $("#id_C_NAME").focus();
        frmMain.form('reset');
        DisableFormValidation(frmMain);
        $("#id_C_ID").val(-1);
    });

    //Delete Button
    $("#lnkDelete").click(function () {
        var rows = grid.datagrid('getSelections');
        if (rows.length > 0) {
            var logids = [];
            $.each(rows, function (idx, obj) {
                logids.push(obj.C_ID);
            });

            $.messager.confirm('Confirm', cfmDelMsg, function (r) {
                if (r) {
                    $.ajax({
                        type: 'POST',
                        data: { C_ID: logids.toString() },
                        url: ParseUrl('Ajax/Controller.asmx/SUPPLIER_Delete')
                    }).done(function (json) { if (ShowMsgJson(json)) { ReloadGrid(); } })
                        .fail(function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); });
                }
            });
        }
        else { ShowMsg(2, unSelectMsg); }
    });

    //Reload Grid
    function ReloadGrid() { grid.datagrid('reload'); }
    EnterToTab(frmMain, UpdateRecords);
    //Edit Button
    $("#lnkEdit").click(function () {
        var rows = grid.datagrid('getSelections');
        var cnt = rows.length;
        if (cnt == 1) { EditRecord(rows[0].C_ID); }
        else if (cnt > 1) { ShowMsg(2, editOneMsg); }
        else if (cnt == 0) { ShowMsg(2, unSelectMsg); }
    });

    function EditRecord(keyNo) {
        $.ajax({
            type: 'POST',
            data: { C_ID: keyNo },
            url: ParseUrl('Ajax/Controller.asmx/SUPPLIER_Get')
        }).done(function (json) {
            if (ShowMsgJson(json)) {
                frmMain.form('load', json.rows[0]);
                ShowDialog(dlgMain, 'Edit');
                $("#id_C_NAME").focus();
            }
        }).fail(function (jqXHR, textStatus, errorThrown) { ShowMsg(0, jqXHR.responseText); });
    }

    //Dialog Buttons Event
    btnOK.click(function () { UpdateRecords(); });
    btnCancel.click(function () { dlgMain.dialog('close'); });
    function UpdateRecords() { DoSubmit(frmMain, ParseUrl("Ajax/Controller.asmx/SUPPLIER_Update"), null, true, dlgMain, ReloadGrid); }
    //init form
    DisableFormValidation(frmMain);
});