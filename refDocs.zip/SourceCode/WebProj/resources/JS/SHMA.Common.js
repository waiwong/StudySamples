﻿
function bindAutocomplete(src, srcName) {
    $("#" + src).autocomplete(srcName, {
        width: 150,
        max: 20,
        scrollHeight: varHeight,
        matchContains: true,
        formatItem: function (data, i, total) { return data.C_ID + "->" + data.C_ID_NAME; },
        formatMatch: function (data, i, total) { return data.C_ID + "->" + data.C_ID_NAME; },
        formatResult: function (data) { return data.C_ID_NAME; }
    });
}

function IntiComboCat(el, reqVal) {
    el.combobox({
        required: reqVal,
        panelHeight: 150,
        //editable: reqVal,
        loader: function (param, success, error) {
            $.ajax({
                type: 'POST',
                url: ParseUrl("Ajax/Controller.asmx/CATEGORY_Get"),
                dataType: 'json',
                success: function (data) { success(data.rows); },
                error: function () { error.apply(this, arguments); }
            });
        },
        filter: function (q, row) {
            return row['C_ID_NAME'].toLowerCase().indexOf(q.toLowerCase()) != -1;
        },
        valueField: 'C_ID',
        textField: 'C_ID_NAME'
    });
}

function IntiComboCCY(el, reqVal) {
    el.combobox({
        required: reqVal,
        panelHeight: 150,
        //editable: reqVal,
        loader: function (param, success, error) {
            $.ajax({
                type: 'POST',
                url: ParseUrl("Ajax/Controller.asmx/CCY_Get"),
                dataType: 'json',
                success: function (data) { success(data.rows); },
                error: function () { error.apply(this, arguments); }
            });
        },
        filter: function (q, row) {
            return row['C_ID_NAME'].toLowerCase().indexOf(q.toLowerCase()) != -1;
        },
        valueField: 'C_ID',
        textField: 'C_ID_NAME'
    });
}

function IntiComboSupplier(el) {
    el.combobox({
        //editable: false,
        required: true,
        panelHeight: 150,
        loader: function (param, success, error) {
            $.ajax({
                type: 'POST',
                url: ParseUrl("Ajax/Controller.asmx/SUPPLIER_Get"),
                data: { page: 1, rows: 1000 },
                dataType: 'json',
                success: function (data) { success(data.rows); },
                error: function () { error.apply(this, arguments); }
            });
        },
        filter: function (q, row) {
            return row['C_ID_NAME'].toLowerCase().indexOf(q.toLowerCase()) != -1;
        },
        valueField: 'C_ID',
        textField: 'C_ID_NAME'
    });
}

function IntiComboAC_NAME(el) {
    el.combobox({
        //editable: false,
        required: true,
        panelHeight: 150,
        loader: function (param, success, error) {
            $.ajax({
                type: 'POST',
                url: ParseUrl("Ajax/Controller.asmx/AC_NAME_Get"),
                //data: { page: 1, rows: 1000 },
                dataType: 'json',
                success: function (data) { success(data.rows); },
                error: function () { error.apply(this, arguments); }
            });
        },
        filter: function (q, row) {
            return row['C_ID_NAME'].toLowerCase().indexOf(q.toLowerCase()) != -1;
        },
        valueField: 'C_ID',
        textField: 'C_ID_NAME'
    });
}

function IntiComboCARDNO(el, reqVal) {
    el.combobox({
        required: reqVal,
        panelHeight: 150,
        //editable: reqVal,
        loader: function (param, success, error) {
            $.ajax({
                type: 'POST',
                url: ParseUrl("Ajax/Controller.asmx/CARD_NO_Get"),
                dataType: 'json',
                success: function (data) { success(data.rows); },
                error: function () { error.apply(this, arguments); }
            });
        },
        filter: function (q, row) {
            return row['C_ID_NAME'].toLowerCase().indexOf(q.toLowerCase()) != -1;
        },
        valueField: 'C_ID',
        textField: 'C_ID_NAME'
    });
}

function IntiComboCARDNO_EQUIPMENT(el) {
    el.combobox({
        //editable: false,
        required: true,
        panelHeight: 150,
        loader: function (param, success, error) {
            $.ajax({
                type: 'POST',
                url: ParseUrl("Ajax/Controller.asmx/CARD_NO_EQUIPMENT_Get"),
                //data: { page: 1, rows: 1000 },
                dataType: 'json',
                success: function (data) { success(data.rows); },
                error: function () { error.apply(this, arguments); }
            });
        },
        filter: function (q, row) {
            return row['C_EQUIPMENT'].toLowerCase().indexOf(q.toLowerCase()) != -1;
        },
        valueField: 'C_EQUIPMENT',
        textField: 'C_EQUIPMENT'
    });
}

function IntiComboCARDNO_VENDOR(el) {
    el.combobox({
        //editable: false,
        required: true,
        panelHeight: 150,
        loader: function (param, success, error) {
            $.ajax({
                type: 'POST',
                url: ParseUrl("Ajax/Controller.asmx/CARD_NO_VENDOR_Get"),
                //data: { page: 1, rows: 1000 },
                dataType: 'json',
                success: function (data) { success(data.rows); },
                error: function () { error.apply(this, arguments); }
            });
        },
        filter: function (q, row) {
            return row['C_VENDOR'].toLowerCase().indexOf(q.toLowerCase()) != -1;
        },
        valueField: 'C_VENDOR',
        textField: 'C_VENDOR'
    });
}

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}