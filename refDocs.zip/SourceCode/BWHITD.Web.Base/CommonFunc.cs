﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using BWHITD.Sys.Common;

namespace BWHITD.Web.Base
{
    /// <summary>
    /// Common Function
    /// </summary>
    public class CommonFunc
    {
        /// <summary>
        /// Encrypt query Param strings
        /// </summary>
        /// <param name="strParam">url Param ,Format(param=value&amp;param=value)</param>
        /// <returns></returns>
        public static string EncryptParam(string strParam)
        {
            string tmpParam = strParam;
            string result = string.Empty;
            if (!string.IsNullOrEmpty(tmpParam))
            {
                ////Replace &amp; 
                tmpParam = tmpParam.Replace("&amp;", HttpUtility.UrlEncode("&amp;"));
                MatchCollection matches = Regex.Matches(tmpParam, @"(([^&=]+)=([^&=#]*))", RegexOptions.Compiled);
                foreach (Match m in matches)
                    result += string.Format("&{0}={1}", m.Groups[2].Value,
                        Security.WebEncryption(HttpUtility.HtmlDecode(m.Groups[3].Value.Replace(HttpUtility.UrlEncode("&amp;"), "&amp;"))));
                result = result.Substring(1);
            }

            return result;
        }

        public static string EncryptUrlParam(string url)
        {
            string openurl = url;
            if (url.IndexOf("?") >= 0)
            {
                if (url.IndexOf("?request") < 0)
                {
                    string strParam = EncryptParam(url.Substring(url.IndexOf("?") + 1));
                    string encryptParamData = string.Concat("request=", Security.WebEncryption(strParam));
                    openurl = url.Substring(0, url.IndexOf("?") + 1) + encryptParamData;
                }
            }

            return openurl;
        }

        internal static void OpenNewWindows(string url)
        {
            OpenNewWindows(null, url);
        }

        internal static void OpenNewWindows(UpdatePanel updatePanel, string url)
        {
            ExecuteClientScript(updatePanel, string.Format("window.open('{0}');", EncryptUrlParam(url)));
        }

        internal static string GetOpenNewWindowsMaxScirpt(string url)
        {
            string encryptUrl = EncryptUrlParam(url);
            string strArguments = "var availHeight = screen.availHeight-70;var availWidth = screen.availWidth-10;"
                + "var arguments = 'height='+availHeight+',width='+availWidth+',status=yes,scrollbars=yes,toolbar=no,menubar=no,resizable=yes,location=no,top = 0, left = 0'";

            string script = string.Format("{0};window.open('{1}','{2}',arguments);", strArguments, url, Guid.NewGuid().ToString().Replace("-", string.Empty));
            return script;
        }

        internal static void OpenNewWindowsMax(string url)
        {
            OpenNewWindowsMaxNoEncrypt(null, EncryptUrlParam(url));
        }

        internal static void OpenNewWindowsMax(UpdatePanel updatePanel, string url)
        {
            OpenNewWindowsMaxNoEncrypt(updatePanel, EncryptUrlParam(url));
        }

        internal static void OpenNewWindowsMaxNoEncrypt(string url)
        {
            OpenNewWindowsMaxNoEncrypt(null, url);
        }

        internal static void OpenNewWindowsMaxNoEncrypt(UpdatePanel updatePanel, string url)
        {
            string script = GetOpenNewWindowsMaxScirpt(url);
            ExecuteClientScript(updatePanel, script);
        }

        /// <summary>
        /// show Message user Alert
        /// </summary>
        /// <param name="msg">message</param>
        internal static void ShowClientMessageBox(string msg)
        {
            ShowClientMessageBox(null, msg);
        }

        /// <summary>
        /// show Message user Alert
        /// </summary>
        /// <param name="updatePanel">updatePanel</param>
        /// <param name="msg">message</param>
        internal static void ShowClientMessageBox(UpdatePanel updatePanel, string msg)
        {
            if (msg == null)
            {
                return;
            }

            ExecuteClientScript(updatePanel,
                                string.Format("alert('{0}')", msg.Replace("\\", "\\\\").Replace("\'", "\"").Replace("\n", "\\n").Replace("\r", "\\r")));
        }

        /// <summary>
        /// Execute JavaScript 
        /// </summary>
        /// <param name="script">Script</param>
        public static void ExecuteClientScript(string script)
        {
            ExecuteClientScript(null, script);
        }

        /// <summary>
        /// Execute JavaScript 
        /// </summary>
        /// <param name="updatePanel">updatePanel</param>
        /// <param name="script">Script</param>
        public static void ExecuteClientScript(UpdatePanel updatePanel, string script)
        {
            if (string.IsNullOrEmpty(script))
            {
                return;
            }

            if (updatePanel == null)
            {
                if (script.IndexOf("<script language=javascript>") < 0)
                {
                    script = string.Format("<script language=javascript>{0}</script>", script);
                }

                (HttpContext.Current.Handler as Page).ClientScript.RegisterStartupScript(typeof(string), Guid.NewGuid().ToString(), script);
            }
            else
            {
                if (script.IndexOf("<script language=javascript>") > 0)
                {
                    script = script.Substring(28).Replace("</script>", string.Empty);
                }

                ScriptManager.RegisterStartupScript(updatePanel, updatePanel.Page.GetType(), Guid.NewGuid().ToString(), script, true);
                updatePanel.Update();
            }
        }

        public static string GetWebClientIP()
        {
            if (HttpContext.Current.Request.ServerVariables["HTTP_VIA"] != null)
            {
                return HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            }
            return HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        }

        /// <summary>
        /// Get Post Request Param
        /// </summary>
        /// <param name="pageReq">Request</param>
        /// <param name="strParam">ParamName</param>
        /// <returns></returns>
        internal static string GetRequestForm(HttpRequest pageReq, string strParam)
        {
            string result = pageReq.Form[strParam];
            if (!string.IsNullOrEmpty(result))
                result = Security.WebDecryption(result);
            else
                result = string.Empty;

            return result;
        }

        /// <summary>
        /// Get Post Request Param
        /// </summary>
        /// <param name="pageReq">Request</param>
        /// <param name="strParam">ParamName</param>
        /// <returns></returns>
        internal static string GetReqFormNoEncrypt(HttpRequest pageReq, string strParam)
        {
            string result = pageReq.Form[strParam];
            if (string.IsNullOrEmpty(result))
            {
                result = string.Empty;
            }

            return result;
        }

        /// <summary>
        /// Get Get Request Param
        /// </summary>
        /// <param name="pageReq">Request</param>
        /// <param name="strParam">ParamName</param>
        /// <returns></returns>
        internal static string GetRequestQuery(HttpRequest pageReq, string strParam)
        {
            string result = pageReq.QueryString[strParam];
            if (!string.IsNullOrEmpty(result))
                result = Security.WebDecryption(result);
            else
                result = string.Empty;

            return result;
        }

        /// <summary>
        /// Get Request Param
        /// </summary>
        /// <param name="pageReq">Request</param>
        /// <param name="strParam">ParamName</param>
        /// <returns></returns>
        public static string GetReqQueryNoEncrypt(HttpRequest pageReq, string strParam)
        {
            string result = pageReq.QueryString[strParam];
            if (string.IsNullOrEmpty(result))
                result = string.Empty;

            return result;
        }

        /// <summary>
        /// Get Request Param
        /// </summary>
        /// <param name="pageReq">Request</param>
        /// <param name="strParam">ParamName</param>
        /// <returns></returns>
        internal static string GetRequestParam(HttpRequest pageReq, string strParam)
        {
            string result = pageReq.Params[strParam];
            if (!string.IsNullOrEmpty(result))
                result = Security.WebDecryption(result);
            else
                result = string.Empty;

            return result;
        }

        /// <summary>
        /// Response Write Message
        /// </summary>
        /// <param name="msgType">0,Info;1 Error;2 Warn</param>
        /// <param name="strMsg">message</param>
        public static void ResponseWriteMsg(int msgType, string strMsg)
        {
            ResponseWriteMsg(msgType, strMsg, null);
        }

        /// <summary>
        /// Response Write Message
        /// </summary>
        /// <param name="ex">Exception</param>
        public static void ResponseWriteMsg(Exception ex)
        {
            string errMsg = ex.ToString();
            ResponseWriteMsg(1, errMsg, ex);
        }

        /// <summary>
        /// Response Write Message
        /// </summary>
        /// <param name="msgType">0,Info;1 Error;2 Warn</param>
        /// <param name="strMsg">message</param>
        /// <param name="ex">Exception</param>
        public static void ResponseWriteMsg(int msgType, string strMsg, Exception ex)
        {
            string showMsg = string.Empty;
            if (msgType == 0 || msgType == 2)
            {
                showMsg = string.Format("<hr/><span style=\"font-weight: bold;font-size: medium;\"><span style=\"color: #ff3300;\">System Information:</span>{0}</span><hr/>", strMsg);
            }
            else
            {
                string exMsg = strMsg;
                if (ex != null)
                    exMsg += "<br/>" + ex.Message;
                showMsg = "<h1>System Error:</h1><hr/>The server is experiencing a problem with the page you requested,Please call IT support!<br />"
                            + "Error URL: " + HttpContext.Current.Request.Url + "<br/>" + "Detail Infomation: "
                            + exMsg + "<hr/>" + DateTime.Now.ToString("yyyyMMdd HH:mm:ss");
                ////showMsg += string.Format("<hr/><br /><a href=\"{0}\">Go Back to Default page</a>", VirtualPathUtility.ToAbsolute("~/modules/Common/Black.aspx"));
            }

            ((HttpApplication)HttpContext.Current.ApplicationInstance).CompleteRequest();
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Write(showMsg);

            StringBuilder sblogMsg = new StringBuilder();
            if (HttpContext.Current.Session != null)
            {
                sblogMsg.AppendFormat("User:{0};Group:{1};Dept:{2}", ContextConst.User, ContextConst.Group, ContextConst.Dept);
            }

            sblogMsg.AppendFormat(";UserIP:{0};Error URL:{1};{2}", HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Url, strMsg);
            switch (msgType)
            {
                case 0:
                    Log.LogInfo(sblogMsg.ToString());
                    break;
                case 1:
                    Log.LogErr(sblogMsg.ToString(), ex);
                    break;
                case 2:
                    Log.LogWarn(sblogMsg.ToString());
                    break;
            }

            HttpContext.Current.Response.End();
        }
    }
}