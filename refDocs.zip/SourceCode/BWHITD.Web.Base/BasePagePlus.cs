﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using BWHITD.Sys.Common;

namespace BWHITD.Web.Base
{
    public partial class BasePage : Page
    {
        #region ShowMsg
        
        protected void ShowMsg(string strMsg)
        {
            this.ShowMsg(EnumConst.MsgType.Success, strMsg);
        }

        protected void ShowMsg(UpdatePanel updatePanel, string strMsg)
        {
            this.ShowMsg(updatePanel, EnumConst.MsgType.Success, strMsg);
        }

        protected void ShowMsg(EnumConst.MsgType msgType, string strMsg)
        {
            this.ShowMsg(null, msgType, strMsg);
        }

        protected void ShowMsg(UpdatePanel updatePanel, EnumConst.MsgType msgType, string strMsg)
        {
            try
            {
                strMsg = strMsg.Replace("\"", "'");
                if (ScriptManager.GetCurrent(this).IsInAsyncPostBack || updatePanel != null)
                {
                    System.Web.UI.WebControls.HiddenField msgHF = this.FindHiddenControl("hfMsgValue");

                    if (msgHF != null)
                    {
                        msgHF.Value = string.Format("{0}{1}", (short)msgType, strMsg);
                        if (msgHF.Parent.Parent != null && msgHF.Parent.Parent.GetType() == typeof(System.Web.UI.UpdatePanel))
                        {
                            ((System.Web.UI.UpdatePanel)msgHF.Parent.Parent).Update();
                        }
                        else if (msgHF.Parent != null && msgHF.Parent.GetType() == typeof(System.Web.UI.UpdatePanel))
                        {
                            ((System.Web.UI.UpdatePanel)msgHF.Parent).Update();
                        }
                    }
                    else
                    {
                        CommonFunc.ShowClientMessageBox(updatePanel, strMsg);
                    }
                }
                else
                {
                    this.ExecuteClientScript(updatePanel, string.Format("ShowMsg({0},\"{1}\")", (short)msgType, strMsg));
                }
            }
            catch (Exception ex)
            {
                Log.LogErr(ex);
                CommonFunc.ShowClientMessageBox(updatePanel, strMsg);
            }
        }

        
        #endregion
    }
}
