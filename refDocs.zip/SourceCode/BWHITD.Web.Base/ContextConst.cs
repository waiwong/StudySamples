﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace BWHITD.Web.Base
{
    public class ContextConst
    {
        public const string SessionPrefix = "MACITD_";
        public const string TempSessionPrefix = "TEMP_";
        private const string ConISVALID = SessionPrefix + "IsValid";
        private const string ConISBCP = SessionPrefix + "ISBCP";
        private const string ConUSER = SessionPrefix + "User";
        private const string ConGROUP = SessionPrefix + "Group";
        private const string ConDEPT = SessionPrefix + "Dept";
        private const string ConFuncRigth = SessionPrefix + "FuncRigth";
        public static bool IsValid
        {
            get
            {
                bool result = SessionHelper.GetValueFromSession<bool>(ConISVALID);
                if (result)
                {
                    if (string.IsNullOrEmpty(User) || string.IsNullOrEmpty(Dept) || string.IsNullOrEmpty(Group))
                    {
                        result = false;
                    }
                }

                return result;
            }
            set
            {
                SessionHelper.SetValutToSession<bool>(ConISVALID, value);
            }
        }

        public static bool IsBCP
        {
            get
            {
                bool result = SessionHelper.GetValueFromSession<bool>(ConISBCP);
                if (result)
                {
                    if (string.IsNullOrEmpty(User) || string.IsNullOrEmpty(Dept) || string.IsNullOrEmpty(Group))
                    {
                        result = false;
                    }
                }

                return result;
            }
            set
            {
                SessionHelper.SetValutToSession<bool>(ConISBCP, value);
            }
        }

        public static string User
        {
            get
            {
                return SessionHelper.GetValueFromSession<string>(ConUSER);
            }
            set
            {
                SessionHelper.SetValutToSession<string>(ConUSER, value);
            }
        }

        public static string Dept
        {
            get
            {
                return SessionHelper.GetValueFromSession<string>(ConDEPT);
            }
            set
            {
                SessionHelper.SetValutToSession<string>(ConDEPT, value);
            }
        }

        public static string Group
        {
            get
            {
                return SessionHelper.GetValueFromSession<string>(ConGROUP);
            }
            set
            {
                SessionHelper.SetValutToSession<string>(ConGROUP, value);
            }
        }

        public static Dictionary<string, bool> DicFuncRight
        {
            get
            {
                if (SessionHelper.CheckValueOfSession(ConFuncRigth))
                {
                    return SessionHelper.GetValueFromSession<Dictionary<string, bool>>(ConFuncRigth);
                }
                else
                {
                    return new Dictionary<string, bool>();
                }
            }
            set
            {
                SessionHelper.SetValutToSession<Dictionary<string, bool>>(ConFuncRigth, value);
            }
        }
    }
}
