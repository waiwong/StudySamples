﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Web;
using BWHITD.Sys.Common;

namespace BWHITD.Web.Base
{
    /// <summary>
    /// Http module that handles encrypted query strings.
    /// </summary>
    public class EncryptUrlQueryString : IHttpModule
    {
        #region IHttpModule Members

        /// <summary>
        /// Initialize the http module.
        /// </summary>
        /// <param name="application">Application, that called this module.</param>
        public void Init(HttpApplication application)
        {
            application.Error += new EventHandler(this.application_Error);
            //// Attach the acquire request state event to check authorize and catch the encrypted query string         
            application.AcquireRequestState += new EventHandler(this.application_AcquireRequestState);
        }

        public void Dispose()
        {
        }

        #endregion

        public void application_AcquireRequestState(object sender, EventArgs e)
        {
            // Get http context from the caller.                   
            HttpContext context = ((HttpApplication)sender).Context;
            HttpRequest req = context.Request;

            string requestUrl = req.Url.ToString();
            if (!requestUrl.Contains(".aspx"))
                return;

            if (!SystemConst.IsAssignDBConn)
            {
                SystemConst.AssignDBConnByFile();
            }

            LogSessValue("AcquireRequestState_BEGIN", context);

            if (SystemConst.SysKey.Equals("SHMA", StringComparison.CurrentCultureIgnoreCase))
            {
                string strHostName = GetComputerName(req.UserHostAddress);
                bool isHost = strHostName.ToUpper().IndexOf("BWHUATITD") >= 0 || strHostName.ToUpper().IndexOf("BWHITD") >= 0 
								|| strHostName.ToUpper().IndexOf("MACITD") >= 0;
#if DEBUG || UAT
                isHost = true;
#endif
                if (isHost)
                {
                    ContextConst.IsValid = true;
                    string strUser = req.ServerVariables["LOGON_USER"];
                    if (!string.IsNullOrEmpty(strUser))
                        ContextConst.User = strUser;
                    else
                        ContextConst.User = string.Empty;
                    ContextConst.Group = "ITD";
                    ContextConst.Dept = "ITD";
                    return;
                }
                else
                {
                    CommonFunc.ResponseWriteMsg(2, "Access Denied!");
                    return;
                }
            }

            bool isFormRpt = requestUrl.ToUpper().Contains("/FORMREPORT/");
            if (req.RequestType.Equals("GET"))
            {
                //if contains FormReport or webservices,don't authorize
                if (!isFormRpt && !requestUrl.Contains(".asmx"))
                {
                    LogSessValue("AcquireRequestState_GET", context);

                    this.Authorize((HttpApplication)sender);

                    //// Check for encrypted query string
                    string encryptedQueryString = req.QueryString["request"];
                    if (!string.IsNullOrEmpty(encryptedQueryString))
                    {
                        ////Decrypt query strings
                        string decryptedQueryString = Security.WebDecryption(encryptedQueryString);
                        ////context.Server.Transfer(req.AppRelativeCurrentExecutionFilePath + "?" + decryptedQueryString);
                        context.RewritePath(req.AppRelativeCurrentExecutionFilePath + "?" + decryptedQueryString, false);
                    }
                }
            }
            else
            {
                ////Check Post Data
                LogSessValue("AcquireRequestState_POST", context);
                bool isAsyncPost = false;
                if (!string.IsNullOrEmpty(req.Form.Get("__ASYNCPOST")))
                {
                    if (!bool.TryParse(req.Form.Get("__ASYNCPOST"), out isAsyncPost))
                        isAsyncPost = false;
                }

                if (!isAsyncPost)
                {
                    //if contains FormReport,don't authorize
                    if (!isFormRpt && !requestUrl.Contains(".asmx") && !requestUrl.Contains(".aspx/"))
                    {
                        if (context.Session == null || !ContextConst.IsValid)
                        {
                            this.Authorize((HttpApplication)sender);
                        }
                    }
                }

                string encryptedQueryString = req.QueryString["request"];
                if (!string.IsNullOrEmpty(encryptedQueryString))
                {
                    Log.LogInfoFormat("requestUrl->{0};encryptedQueryString->{1}",
                                    requestUrl, encryptedQueryString);
                }
            }

            LogSessValue("AcquireRequestState_END", context);
        }

        private void Authorize(HttpApplication app)
        {
            bool isGetFunctionRight = true;
            HttpContext context = app.Context;
            HttpRequest req = context.Request;
            bool isDefaultPage = req.RawUrl.ToString().ToLower().Contains("/home.aspx")
                || req.RawUrl.ToString().ToLower().Contains("/default.aspx");
            int validCode = context.Session == null ? 1 : 0;

            string strMsg = string.Empty;
            if (isDefaultPage || !ContextConst.IsValid)
            {
                LogSessValue("Authorize_START", context);
                ////check get params   
                string strUser = string.Empty, strGroup = string.Empty, strDate = string.Empty, strTime = string.Empty, strDept = string.Empty;

#if DEBUG
                strUser = CommonFunc.GetReqQueryNoEncrypt(req, "U");
                strGroup = CommonFunc.GetReqQueryNoEncrypt(req, "G");
                strDept = CommonFunc.GetReqQueryNoEncrypt(req, "D");
#endif
                if (string.IsNullOrEmpty(strUser) || string.IsNullOrEmpty(strDept))
                {
                    if (req.Form.Count > 0)
                    {
                        strUser = CommonFunc.GetRequestForm(req, "U");
                        strGroup = CommonFunc.GetRequestForm(req, "G");
                        strDate = CommonFunc.GetRequestForm(req, "T1");
                        strTime = CommonFunc.GetRequestForm(req, "T2");
                        strDept = CommonFunc.GetRequestForm(req, "D");
                    }
                    else if (req.QueryString.Count > 0)
                    {
                        strUser = CommonFunc.GetRequestQuery(req, "U");
                        strGroup = CommonFunc.GetRequestQuery(req, "G");
                        strDate = CommonFunc.GetRequestQuery(req, "T1");
                        strTime = CommonFunc.GetRequestQuery(req, "T2");
                        strDept = CommonFunc.GetRequestQuery(req, "D");
                    }
                }
#if DEBUG
                strDate = DateTime.Now.ToString("yyyy-MM-dd");
                strTime = DateTime.Now.ToString("HH:mm:ss");
#endif
                if (string.IsNullOrEmpty(strDept))
                {
                    strDept = string.Empty;
                }

                if (string.IsNullOrEmpty(strGroup))
                {
                    strGroup = string.Empty;
                }

                validCode = 1;
                if (!string.IsNullOrEmpty(strUser) && !string.IsNullOrEmpty(strDate) && !string.IsNullOrEmpty(strTime))
                {
                    DateTime callDT;
                    if (DateTime.TryParse(strDate + " " + strTime, out callDT))
                    {
                        if (callDT.AddMinutes(1).CompareTo(DateTime.Now) > 0)
                        {
                            ContextConst.IsBCP = SystemConst.IsBCP;

                            //Get User Group from ITD_Menu
                            if (!string.IsNullOrEmpty(strGroup) && !strGroup.Contains(",") && !SystemConst.DBConn_ITDMENU.IsEmpty)
                            {
                                try
                                {
                                    SystemConst.DBConn_ITDMENU.ConnectTimeout = 5;
                                    StringBuilder sbGroup = new StringBuilder();
                                    using (DB dbi = new DB(SystemConst.DBConn_ITDMENU))
                                    {
                                        dbi.NeedLog = false;
                                        string sql = string.Format("SELECT DISTINCT Group_ID FROM dbo.GROUP_USERS WHERE UserID = '{0}' "
                                                                   + " AND Group_ID LIKE '{1}_%'", strUser, SystemConst.SysKey);
                                        using (SqlDataReader sqlDR = dbi.GetDataReader(sql))
                                        {
                                            while (sqlDR.Read())
                                            {
                                                sbGroup.AppendFormat(",{0}", sqlDR[0]);
                                            }
                                        }
                                    }

                                    if (sbGroup.Length > 0)
                                        strGroup = sbGroup.ToString().Substring(1);
                                }
                                catch (Exception ex)
                                {
                                    Log.LogErr("Get User Group from ITD_Menu", ex);
                                }
                            }

                            StringBuilder sbMsg = new StringBuilder();
                            sbMsg.AppendFormat("{6};U<{0}>;G<{1}>;D<{2}>;T1<{3}>;T2<{4}>;Now<{5}>;", strUser, strGroup, strDept,
                                strDate, strTime, DateTime.Now.ToString("yyyyMMdd HH:mm:ss"), SystemConst.SysKey);
                            System.Collections.Specialized.NameValueCollection getVar = req.ServerVariables;

                            string[] temp = new string[] { "LOGON_USER", "REMOTE_ADDR" };
                            foreach (string item in temp)
                            {
                                sbMsg.AppendFormat("{0}<{1}>;", item, getVar[item]);
                            }

                            Log.LogInfo(sbMsg.ToString());

                            validCode = 0;

                            if (strDept.Length > 3)
                                strDept = strDept.Substring(0, 3);

                            ContextConst.IsValid = true;
                            ContextConst.User = strUser;
                            ContextConst.Group = strGroup;
                            ContextConst.Dept = strDept;

                            LogSessValue("Authorize_END_BeforeSleep", context);
                            //int iwait = 1;
                            //while (iwait < 60)
                            //{
                            //    ContextConst.IsValid = true;
                            //    ContextConst.User = strUser;
                            //    ContextConst.Group = strGroup;
                            //    ContextConst.Dept = strDept;
                            //    System.Threading.Thread.Sleep(2 * 1000);
                            //    if (!string.IsNullOrEmpty(ContextConst.User))
                            //    {
                            //        break;
                            //    }

                            //    iwait++;
                            //}

                            LogSessValue("Authorize_END_AfterSleep", context);
                        }
                    }
                }
            }

            if (isGetFunctionRight && ContextConst.DicFuncRight.Count > 0)
            {
                string requestUrl = req.RawUrl.ToString();
                string curPage = requestUrl;
                if (!requestUrl.ToLower().StartsWith("/modules") && !requestUrl.ToLower().StartsWith("/page") && !requestUrl.ToLower().StartsWith("/cpmreporting"))
                    curPage = requestUrl.Substring(requestUrl.Substring(1).IndexOf('/') + 1);

                if (curPage.Contains("?"))
                    curPage = curPage.Substring(0, curPage.IndexOf("?"));
                Dictionary<string, bool> dicFunctionRight = ContextConst.DicFuncRight;
                if (dicFunctionRight.ContainsKey(curPage))
                {
                    if (!dicFunctionRight[curPage])
                        validCode = 2;
                }
            }

            switch (validCode)
            {
                case 1:
                    if (req.RawUrl.ToUpper().ToString().Contains("CPMPLUSWEB"))
                        strMsg = "Connection Interrupted. Please retry from \"CPM System\" or \"ITD Menu\"";
                    else
                        strMsg = "Connection Interrupted. Please retry from \"ITD Menu\"";
                    CommonFunc.ResponseWriteMsg(2, strMsg);
                    break;
                case 2:
                    strMsg = "Access Denied!";
                    CommonFunc.ResponseWriteMsg(2, strMsg);
                    break;
            }
        }

        protected void application_Error(object sender, EventArgs e)
        {
            HttpApplication application = (HttpApplication)sender;
            HttpContext context = application.Context;
            Exception currentError = context.Server.GetLastError();

            if (!context.Items.Contains("System.Web.UI.PageRequestManager:AsyncPostBackError")
                || !Convert.ToBoolean(context.Items["System.Web.UI.PageRequestManager:AsyncPostBackError"]))
            {
                if (currentError != null)
                {
                    string errMsg = currentError.ToString();
                    if (currentError.InnerException != null)
                        currentError = currentError.InnerException;
                    CommonFunc.ResponseWriteMsg(1, errMsg, currentError);
                }
            }
            else if (currentError != null)
            {
                StringBuilder sblogMsg = new StringBuilder();
                sblogMsg.Append("AsyncPostBackError-->");
                sblogMsg.AppendFormat("User:{0};Group:{1};Dept:{2}", ContextConst.User, ContextConst.Group, ContextConst.Dept);
                sblogMsg.AppendFormat(";UserIP:{0};Error URL:{1}", context.Request.UserHostAddress, context.Request.Url);
                Log.LogErr(sblogMsg.ToString(), currentError);
            }
        }

        private void LogSessValue(string location, HttpContext context)
        {
            if (context.Session == null)
            {
                Log.LogInfoFormat("context.Session is null:{0}->{1}", location, context.Request.RawUrl);
            }
            else
            {
                System.Text.StringBuilder sblogMsg = new System.Text.StringBuilder();
                sblogMsg.AppendFormat("context.Session==>Location:{0}->SessionID:{1}->Count:{2}->IsNewSession:{3}->{4}->{5}",
                    location, context.Session.SessionID, context.Session.Count, context.Session.IsNewSession, context.Request.RawUrl, context.Request.RequestType);

                sblogMsg.AppendFormat(";User:{0};Group:{1};Dept:{2}", ContextConst.User, ContextConst.Group, ContextConst.Dept);
                Log.LogInfo(sblogMsg.ToString());
            }
        }

        private string GetComputerName(string clientIP)
        {
            try
            {
                var hostEntry = System.Net.Dns.GetHostEntry(clientIP);
                return hostEntry.HostName;
            }
            catch
            {
                return string.Empty;
            }
        }
    }
}