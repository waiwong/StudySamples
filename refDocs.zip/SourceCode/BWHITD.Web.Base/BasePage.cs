﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using BWHITD.Sys.Common;

namespace BWHITD.Web.Base
{
    [CLSCompliant(true)]
    public partial class BasePage : Page
    {
        #region GetRequest
        protected virtual string GetRequestQuery(string strParam)
        {
            string result = CommonFunc.GetRequestQuery(this.Request, strParam);
            if (string.IsNullOrEmpty(result))
                result = CommonFunc.GetRequestForm(this.Request, strParam);
            return result;
        }

        protected virtual string GetRequestQueryNoEncrypt(string strParam)
        {
            string result = CommonFunc.GetReqQueryNoEncrypt(this.Request, strParam);
            if (string.IsNullOrEmpty(result))
                result = CommonFunc.GetReqFormNoEncrypt(this.Request, strParam);
            return result;
        }
        #endregion

        #region EncryptParam
        /// <summary>
        /// Encrypt query Param strings
        /// </summary>
        /// <param name="strParam">url Param,Format(param=value&amp;param=value)</param>
        /// <returns></returns>
        protected virtual string EncryptParam(string strParam)
        {
            return CommonFunc.EncryptParam(strParam);
        }

        protected virtual string EncryptUrlParam(string url)
        {
            return CommonFunc.EncryptUrlParam(url);
        }
        #endregion

        #region OpenNewWindows
        protected virtual void OpenNewWindows(string url)
        {
            CommonFunc.OpenNewWindows(url);
        }

        protected virtual void OpenNewWindowsMax(string url)
        {
            CommonFunc.OpenNewWindowsMax(this.EncryptUrlParam(url));
        }

        protected virtual void OpenNewWindowsMaxNoEncrypt(string url)
        {
            CommonFunc.OpenNewWindowsMaxNoEncrypt(url);
        }

        protected virtual void OpenNewWindowsMaxNoEncrypt(UpdatePanel updatePanel, string url)
        {
            CommonFunc.OpenNewWindowsMaxNoEncrypt(updatePanel, url);
        }
        #endregion

        #region ExecuteClientScript
        protected void ExecuteClientScript(string script)
        {
            this.ExecuteClientScript(null, script);
        }

        protected void ExecuteClientScript(UpdatePanel updatePanel, string script)
        {
            this.ExecuteClientScript(updatePanel, script, true);
        }

        protected void ExecuteClientScript(UpdatePanel updatePanel, string script, bool unblockUI)
        {
            System.Web.UI.WebControls.HiddenField unblockUIHF = this.FindHiddenControl("hfUnblockUI");

            if (unblockUIHF != null)
            {
                unblockUIHF.Value = unblockUI ? "YES" : "NO";

                if (unblockUIHF.Parent.Parent != null && unblockUIHF.Parent.Parent.GetType() == typeof(System.Web.UI.UpdatePanel))
                {
                    ((System.Web.UI.UpdatePanel)unblockUIHF.Parent.Parent).Update();
                }
                else if (unblockUIHF.Parent != null && unblockUIHF.Parent.GetType() == typeof(System.Web.UI.UpdatePanel))
                {
                    ((System.Web.UI.UpdatePanel)unblockUIHF.Parent).Update();
                }
            }

            CommonFunc.ExecuteClientScript(updatePanel, script);
        }
        #endregion

        #region Session Handle

        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
            if (!IsPostBack)
            {
                SysUtil.StartLog();
                List<string> lstSessKey = new List<string>();
                List<string> listDelKey = new List<string>();
                foreach (string key in Session.Keys)
                {
                    lstSessKey.Add(key);
                    if (key.StartsWith(this.TmpSessionPrefix))
                    {
                        listDelKey.Add(key);
                    }
                }

                if (listDelKey.Count > 0)
                    Log.LogInfoFormat("RemoveSess:{0}", string.Join(",", listDelKey.ToArray()));
                Log.LogInfoFormat("CurrentSess:{0}", string.Join(",", lstSessKey.ToArray()));

                foreach (string key in listDelKey)
                {
                    SessionHelper.Clear(key);
                }

                SysUtil.StopLog("OnPreInit_RemoveSession");
            }
        }

        private string TmpSessionPrefix
        {
            get
            {
                return ContextConst.TempSessionPrefix + this.GetType().Name + "_";
            }
        }

        protected void SetValutToSession<T>(string key, T value)
        {
            SessionHelper.SetValutToSession<T>(this.TmpSessionPrefix + key, value);
        }

        protected T GetValueFromSession<T>(string key)
        {
            return SessionHelper.GetValueFromSession<T>(this.TmpSessionPrefix + key, default(T));
        }

        protected T GetValueFromSession<T>(string key, T defaulValue)
        {
            return SessionHelper.GetValueFromSession<T>(this.TmpSessionPrefix + key, defaulValue);
        }

        protected bool CheckValueOfSession(string key)
        {
            return SessionHelper.CheckValueOfSession(this.TmpSessionPrefix + key);
        }

        //protected void ClearSession(string key)
        //{
        //    SessionHelper.Clear(this.TmpSessionPrefix + key);
        //}

        #endregion

        protected enum SortOrder
        {
            ASC,
            DESC
        }

        protected List<T> SortList<T>(List<T> list, string sortBy, SortOrder direction)
        {
            if (string.IsNullOrEmpty(sortBy))
                return list;

            PropertyInfo property = list.GetType().GetGenericArguments()[0].GetProperty(sortBy);
            if (direction == SortOrder.ASC)
            {
                return list.OrderBy(e => property.GetValue(e, null)).ToList<T>();
            }
            else
            {
                return list.OrderByDescending(e => property.GetValue(e, null)).ToList<T>();
            }
        }

        protected System.Web.UI.WebControls.HiddenField FindHiddenControl(string strControlID)
        {
            System.Web.UI.WebControls.HiddenField result = null;
            System.Web.UI.Control findControl = this.FindControl(strControlID);
            if (findControl == null && this.Master != null)
            {
                findControl = this.Master.FindControl(strControlID);
            }

            if (findControl != null && findControl.GetType() == typeof(System.Web.UI.WebControls.HiddenField))
            {
                result = (System.Web.UI.WebControls.HiddenField)findControl;
            }

            return result;
        }
    }
}