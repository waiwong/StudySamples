﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;

namespace BWHITD.Web.Base
{
    public class EntityUtilWeb
    {
        /// <summary>
        /// Create a new Entity from http request params
        /// </summary>
        /// <typeparam name="T">Entity</typeparam>
        /// <param name="drInit">DataRow from DataTable</param>
        /// <returns></returns>
        public static T Create<T>(HttpRequest req)
        {
            T pINs = (T)Activator.CreateInstance(typeof(T));
            PropertyInfo[] piIns = pINs.GetType().GetProperties();
            for (int i = 0; i < piIns.Length; i++)
            {
                string piName = piIns[i].Name;
                if (piIns[i].CanWrite && req.Form.AllKeys.Contains(piName) && req.Form[piName] != null)
                {
                    Type propType = piIns[i].PropertyType;
                    if (propType.IsGenericType && propType.GetGenericTypeDefinition() == typeof(Nullable<>))
                    {
                        propType = propType.GetGenericArguments()[0];
                    }

                    string val = req.Form[piName];
                    if (!string.IsNullOrEmpty(val))
                    {
                        if (propType == typeof(decimal))
                            piIns[i].SetValue(pINs, Convert.ToDecimal(val), null);
                        else if (propType == typeof(int))
                            piIns[i].SetValue(pINs, Convert.ToInt32(val), null);
                        else if (propType == typeof(DateTime))
                        {
                            DateTime dt;
                            if (DateTime.TryParse(val, out dt))
                                piIns[i].SetValue(pINs, dt, null);
                        }
                        else
                            piIns[i].SetValue(pINs, val.ToString().Trim(), null);
                    }
                }
            }

            return pINs;
        }
    }
}
