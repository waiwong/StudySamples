﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web;
using System.Web.UI;
using BWHITD.Sys.Common;

namespace BWHITD.Web.Base
{
    public class BaseMasterPage : System.Web.UI.MasterPage
    {
        #region GetRequest
        protected virtual string GetRequestQuery(string strParam)
        {
            string result = CommonFunc.GetRequestQuery(this.Request, strParam);
            if (string.IsNullOrEmpty(result))
                result = CommonFunc.GetRequestForm(this.Request, strParam);
            return result;
        }

        protected virtual string GetRequestQueryNoEncrypt(string strParam)
        {
            string result = CommonFunc.GetReqQueryNoEncrypt(this.Request, strParam);
            if (string.IsNullOrEmpty(result))
                result = CommonFunc.GetReqFormNoEncrypt(this.Request, strParam);
            return result;
        }
        #endregion

        /// <summary>
        /// ShowErrMsg
        /// </summary>
        /// <param name="strMsg">strMsg</param>
        public virtual void ShowErrMsg(string strMsg)
        {
            CommonFunc.ShowClientMessageBox(strMsg);
        }

        /// <summary>
        /// ShowMsg
        /// </summary>
        /// <param name="strMsg">strMsg</param>
        public virtual void ShowInfoMsg(string strMsg)
        {
            CommonFunc.ShowClientMessageBox(strMsg);
        }

        #region Session Handle

        protected void SetValutToSession<T>(string key, T value)
        {
            SessionHelper.SetValutToSession<T>(ContextConst.SessionPrefix + key, value);
        }

        protected T GetValueFromSession<T>(string key)
        {
            return SessionHelper.GetValueFromSession<T>(ContextConst.SessionPrefix + key, default(T));
        }

        protected T GetValueFromSession<T>(string key, T defaulValue)
        {
            return SessionHelper.GetValueFromSession<T>(ContextConst.SessionPrefix + key, defaulValue);
        }

        protected bool CheckValueOfSession(string key)
        {
            return SessionHelper.CheckValueOfSession(ContextConst.SessionPrefix + key);
        }

        #endregion
    }
}