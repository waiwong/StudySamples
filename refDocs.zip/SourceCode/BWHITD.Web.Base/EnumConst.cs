﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BWHITD.Web.Base
{
    public class EnumConst
    {
        public enum MsgType
        {
            Error = 0,
            Success = 1,
            Warn = 2,
        }
    }
}
